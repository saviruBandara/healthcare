<div id="footer" class="footer" role="contentinfo">
	<div class="footer-bar">
		<div class="footer-menu menu section-wrapper">
			<?=$footerMenu;?>
		</div>
	</div><!-- /footer-bar -->
	
	<div class="footer-info">
		<div class="info-topbar section-wrapper">
					<?php 
			  $phone = str_replace(" ", "", convertText('footer','hotelPhoneText','htmlNone'));
			  $fax = str_replace(" ", "", convertText('footer','hotelFaxText','htmlNone'));				
		?>
		<div class="footer-address">
			<h3 class="hotel-name">
				<?=convertText('footer','hotelName','htmlStrip');?>
			</h3>
			<p class="address-details">
				<?=convertText('footer','hoteladdress','htmlStrip');?>
			</p>
			<p class="footer-phone">
			<span class="phone1">
				<?=convertText('footer','hotelPhoneLabel','htmlStrip');?> 
				<a href="tel:<?=$phone;?>">
					<?=convertText('footer','hotelPhoneText','htmlStrip');?>
				</a>
			</span>
			<span class="fax">
				<?=convertText('footer','hotelFaxLabel','htmlStrip');?> 
				<?=convertText('footer','hotelFaxText','htmlStrip');?>
			</span>
			</p>
			<p class="copyright">
				<span>Copyright &copy; <?= date("Y") ?> </span> 
				<?=convertText('footer','hotelName','htmlStrip');?>
				<?=convertText('footer','allRightsText','htmlStrip');?>
			</p>
			
		</div>
		<div class="footer-logos">
			<?php $logos=array('okura','nikko','jal'); 
				foreach($logos as $logo){?>
				<div class="footer-logo <?=$logo?>">
                                    <a href="">
                                        <img src="images/<?=$logo?>.png" />
                                    </a>
				</div>
			<?php
				}
			?>
		</div>
		</div>
		<div class="info-subhotels section-wrapper no-mobile active">
			<h3><?=convertText('footer','info-hotels-title','htmlStrip');?></h3>
			<ul class="hotelswrapper">
			<?php 
				$out="";
				$subhotels=array(array_fill(0,2,"hokkaido"),array_fill(0,2,"tohoku"),
				array_fill(0,9,"kanato"),array_fill(0,5,"chubu/hukuriko"),array_fill(0,5,"kansai"),
				array_fill(0,3,"chubu/shikoku"),array_fill(0,4,"kyusyu"),array_fill(0,4,"okinawa"),array_fill(0,9,"china"),
				array_fill(0,8,"asia/pacific"),array_fill(0,2,"americas"),array_fill(0,2,"europe"));
				foreach($subhotels as $group){
					$i=$j=0;
					$out.="<li class=\"group\"><h4>!+ TEXT subHotels {$group[1]}Title htmlStrip +!</h4>";
					$out.="<ul>";
					foreach($group as $hotel){
						$j++;
                                                $atext=convertText('subcompanies',"subcompany-{$group[1]}{$j}",'htmlStrip');
						$out.=<<<EOD
						<li>
							<a href="{$group[1]}{$j}">
                                                            {$atext}
							</a>
						</li>
EOD;
						$i++;
					}
					$out.="</ul>";
					$out.="</li>";
				}
				echo $out;
			?>
			</ul>
		</div>
	</div><!-- /footer-info -->
</div> <!-- END FOOTER -->	
</body>
</html>
