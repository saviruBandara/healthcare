<?php
try {
    require './inc.template.header-open.php';

    session_start();
    if (isset($_SESSION["logmsg"]) && $_SESSION["logmsg"] != "wrong") {
        $usesess = $_SESSION["logmsg"];
    }
    ?>

    </head>

    <body id='page_<?=$pageKey ?>'>    
        <div id="header" class="section-wrapper section-outerwrapper header map-no-print" role="banner">
            <div class="section-inner header-content posrel">
                <div id="branding" class="logo float-l">
                    <img src="images/logo.gif" alt="logo"/>
                </div>
                <!-- /logo -->
                <div id="topbar">
                    <div id="languages" class="lang">
                        <ul class="ltr" dir="ltr">
                            <li class="item1 active"><?php echo convertText('languages',"langen",'htmlStrip');?></li>
                            <li class="item2"><?php echo convertText('languages',"langsin",'htmlStrip');?></li>
                            <li class="item3 last"><?php echo convertText('languages',"langtam",'htmlStrip');?></li>
                        </ul>
                    </div>
                    <div id="navigation" class="float-l" >
                        <?--php if (!$pageKey === "home") { ?>
                        <ul class="shortcuts">
                            <li class="shortcut1 item1 itemr9 level1 home"><a href="index.php"><?php echo convertText('mainMenu',"home",'htmlStrip');?></a></li>
                            <li class="shortcut2 item2 itemr8 level1 restaurantsandbar"><a href="profile.php"><?php echo convertText('mainMenu',"profile",'htmlStrip');?></a></li>
                            <li class="shortcut3 item3 itemr7 level1 meetingsandevents"><a href=""><?php echo convertText('mainMenu',"profile",'htmlStrip');?></a></li>
                            <li class="shortcut4 item4 itemr6 level1 facilities"><a href=""><?php echo convertText('mainMenu',"profile",'htmlStrip');?></a></li>
                        </ul>
                        <?--php }else{ ?><?--php } ?>
                    </div><!-- /navigation -->
                </div>
            </div><!-- /header-content -->
        </div><!-- /header -->
        <?php
    } catch (Exception $exc) {
        redirect("404.php");
    }
    ?>


    <?php
    if (isset($_REQUEST["uiStatus"])) {
        $uistatus = $_REQUEST["uiStatus"];
        ?>
        <div id="dialog-message" title="Something Wrong">
            <p>
                <?php if ($uistatus === "sendmail") { ?>
                    Your account is now ready.Please go through the email for remaining process
                <?php } elseif ($uistatus === "emailLink") { ?>
                    Please activate your account by clicking the activation link  <a class="error-ui" href="#">Did'nt received the mail</a>
                <?php } elseif ($uistatus === "invalid") { ?>
                    Invalid Data Provided,Please re-login with correct username and password.
                <?php } elseif ($uistatus === "deactivate") { ?>
                    Deactivated, <a class="error-ui" href="#">Did'nt received the mail</a>
                <?php } ?>
            </p>        
        </div>
    <?php } ?>
