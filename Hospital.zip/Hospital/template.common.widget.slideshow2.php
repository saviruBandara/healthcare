<?php
//$query = "select mediamanager.idmediaManager,mediamanager.mediaManagercol";
//$query .=" from mediamanager,mediaobject_has_mediamanager where";
//$query .=" mediamanager.idmediaManager=mediaobject_has_mediamanager.mediaManager_idmediaManager";
//$mediaObject = $PDO_fun->getValue($query);
//$oout;
//$i = 1;
//if ($mediaObject->rowCount() > 0) {
//    while ($row = $mediaObject->fetchObject()) {
//        $oout .="<img class=\"slide item{$i}\" src=\"../" . $row->mediaManagercol . "\"/>";
//        $i++;
//    }
//    echo $oout;
//} else {
//    
//}
?>
<div class="slideshow">

    <!-- slider revolution start -->
    <!-- ================ -->
    <div class="slider-banner-container">
        <div class="slider-banner-fullscreen">
            <ul class="slides">

                <!-- slide 1 start -->
                <!-- ================ -->
                <li data-transition="random-static" data-slotamount="7" data-masterspeed="500" data-saveperformance="on" data-title="Welcome To Walawwawatta">

                    <!-- main image -->
                    <img src="images/slides/medicalSol.jpg" alt="slidebg1" data-bgposition="center top"  data-bgrepeat="no-repeat" data-bgfit="cover">

                    <!-- Transparent Background -->
                    <div class="tp-caption dark-translucent-bg"
                         data-x="center"
                         data-y="bottom"
                         data-speed="500"
                         data-easing="easeOutQuad"
                         data-start="0">
                    </div>

                    <!-- LAYER NR. 1 -->
                    <div class="tp-caption sfr stl xlarge_white"
                         data-x="center"
                         data-y="70"
                         data-speed="200"
                         data-easing="easeOutQuad"
                         data-start="1000"
                         data-end="2500"
                         data-splitin="chars"
                         data-elementdelay="0.1"
                         data-endelementdelay="0.1"
                         data-splitout="chars">Luxury Facilites
                    </div>

                    <!-- LAYER NR. 2 -->
                    <div class="tp-caption sfl str xlarge_white"
                         data-x="center"
                         data-y="70"
                         data-speed="200"
                         data-easing="easeOutQuad"
                         data-start="2500"
                         data-end="4000"
                         data-splitin="chars"
                         data-elementdelay="0.1"
                         data-endelementdelay="0.1"
                         data-splitout="chars">Best Services
                    </div>

                    <!-- LAYER NR. 3 -->
                    <div class="tp-caption sfr stt xlarge_white"
                         data-x="center"
                         data-y="70"
                         data-speed="200"
                         data-easing="easeOutQuad"
                         data-start="4000"
                         data-end="6000"
                         data-splitin="chars"
                         data-elementdelay="0.1"
                         data-endelementdelay="0.1"
                         data-splitout="chars"
                         data-endspeed="400">Things To Do
                    </div>					

                    <!-- LAYER NR. 4 -->
                    <div class="tp-caption sft fadeout text-center large_white"
                         data-x="center"
                         data-y="70"
                         data-speed="500"
                         data-easing="easeOutQuad"
                         data-start="6400"
                         data-end="10000"><br><span class="logo-font">Walawwa Watta <span class="text-default">Resort</span>
                    </div>	

                    <!-- LAYER NR. 5 -->
                    <div class="tp-caption sfr fadeout"
                         data-x="center"
                         data-y="210"
                         data-hoffset="-232"
                         data-speed="500"
                         data-easing="easeOutQuad"
                         data-start="1000"
                         data-end="5500"><span class="icon large circle"><i class="fa fa-bed"></i></span>
                    </div>

                    <!-- LAYER NR. 6 -->
                    <div class="tp-caption sfl fadeout"
                         data-x="center"
                         data-y="210"
                         data-speed="500"
                         data-easing="easeOutQuad"
                         data-start="2500"
                         data-end="5500"><span class="icon large circle"><i class="fa fa-cutlery"></i></span>
                    </div>

                    <!-- LAYER NR. 7 -->
                    <div class="tp-caption sfr fadeout"
                         data-x="center"
                         data-y="210"
                         data-hoffset="232"
                         data-speed="500"
                         data-easing="easeOutQuad"
                         data-start="4000"
                         data-end="5500"><span class="icon large circle"><i class="fa fa-heart"></i></span>
                    </div>

                    <!-- LAYER NR. 8 -->
                    <div class="tp-caption ZoomIn fadeout text-center tp-resizeme large_white"
                         data-x="center"
                         data-y="170"
                         data-speed="500"
                         data-easing="easeOutQuad"
                         data-start="6400"
                         data-end="10000"><div class="separator light"></div>
                    </div>	

                    <!-- LAYER NR. 9 -->
                    <div class="tp-caption sft fadeout medium_white text-center"
                         data-x="center"
                         data-y="210"
                         data-speed="500"
                         data-easing="easeOutQuad"
                         data-start="5800"
                         data-end="10000"
                         data-endspeed="600">Mirissa beach and night life make <br> its a popular tourist destination.itis also a fishing port and one of the   <br>island's main Wale and Dolpin watching lacations...
                    </div>

                    <div class="tp-caption fade fadeout"
                         data-x="center"
                         data-y="bottom"
                         data-voffset="-100"
                         data-speed="500"
                         data-easing="easeOutQuad"
                         data-start="2000"
                         data-endspeed="200">
                        <a href="#hotel" class="btn btn-lg moving smooth-scroll"><i class="icon-down-open-big"></i><i class="icon-down-open-big"></i><i class="icon-down-open-big"></i></a>
                    </div> 
                </li>
                <!-- slide 1 end -->

                <!-- slide 2 start -->
                <!-- ================ -->
                <li data-transition="random-static" data-slotamount="7" data-masterspeed="500" data-saveperformance="on" data-title="Luxury Facilites">

                    <!-- main image -->
                    <img src="images/slides/ladydoc.jpg" alt="slidebg2" data-bgposition="center top"  data-bgrepeat="no-repeat" data-bgfit="cover">

                    <!-- Transparent Background -->
                    <div class="tp-caption dark-translucent-bg"
                         data-x="center"
                         data-y="bottom"
                         data-speed="500"
                         data-easing="easeOutQuad"
                         data-start="0">
                    </div>

                    <!-- LAYER NR. 1 -->
                    <div class="tp-caption sfb fadeout large_white"
                         data-x="left"
                         data-y="70"
                         data-speed="500"
                         data-start="1000"
                         data-easing="easeOutQuad"
                         data-end="10000"><span class="logo-font">Walawwawatta</span><br> Luxury Facilites
                    </div>	

                    <!-- LAYER NR. 2 -->
                    <div class="tp-caption sfb fadeout text-left medium_white"
                         data-x="left"
                         data-y="200" 
                         data-speed="500"
                         data-start="1300"
                         data-easing="easeOutQuad"
                         data-endspeed="600"><a href="#"><span class="icon default-bg circle small hidden-xs"><i class="fa fa-bed"></i></span> Comfortable Beds.</a>
                    </div>

                    <!-- LAYER NR. 3 -->
                    <div class="tp-caption sfb fadeout text-left medium_white"
                         data-x="left"
                         data-y="260" 
                         data-speed="500"
                         data-start="1600"
                         data-easing="easeOutQuad"
                         data-endspeed="600"><a href="#"><span class="icon default-bg circle small hidden-xs"><i class="icon-globe-alt"></i></span> TV with Satelight Antena.</a>
                    </div>

                    <!-- LAYER NR. 4 -->
                    <div class="tp-caption sfb fadeout text-left medium_white"
                         data-x="left"
                         data-y="320" 
                         data-speed="500"
                         data-start="1900"
                         data-easing="easeOutQuad"
                         data-endspeed="600"><a href="#"><span class="icon default-bg circle small hidden-xs"><i class="fa fa-leaf"></i></span> Garden Or Balcony</a>
                    </div>

                    <!-- LAYER NR. 5 -->
                    <div class="tp-caption sfb fadeout text-left medium_white"
                         data-x="left"
                         data-y="380" 
                         data-speed="500"
                         data-start="2200"
                         data-easing="easeOutQuad"
                         data-endspeed="600"><a href="#"><span class="icon default-bg circle small hidden-xs"><i class="fa fa-cutlery"></i></span> Site Restaurant</a>
                    </div>

                    <div class="tp-caption sfb fadeout text-right large_white hidden-xs"
                         data-x="right"
                         data-y="180"
                         data-speed="500"
                         data-start="2200"
                         data-easing="easeOutQuad"><img id="logo_img" src="images/logo1.png" alt="walawwa watta"><span class="logo-font">Sri Lankan Style <span class="text-default"><br>Lunch Free.</span><br><span class="icon large circle"><i class="fa fa-cutlery pr-5"></i></span>
                    </div>

                    <div class="tp-caption fade fadeout"
                         data-x="center"
                         data-y="bottom"
                         data-voffset="-100"
                         data-speed="500"
                         data-easing="easeOutQuad"
                         data-start="2000"
                         data-endspeed="200">
                        <a href="#hotel4" class="btn btn-lg moving smooth-scroll"><i class="icon-down-open-big"></i><i class="icon-down-open-big"></i><i class="icon-down-open-big"></i></a>
                    </div>	
                </li>
                <!-- slide 2 end -->

                <!-- slide 3 start -->
                <!-- ================ -->
                <li data-transition="random-static" data-slotamount="7" data-masterspeed="500" data-saveperformance="on" data-title="Things To Do">

                    <!-- main image -->
                    <img src="images/slides/labTesting.jpg" alt="slidebg3" data-bgposition="center top"  data-bgrepeat="no-repeat" data-bgfit="cover">

                    <!-- Transparent Background -->
                    <div class="tp-caption dark-translucent-bg"
                         data-x="center"
                         data-y="bottom"
                         data-speed="600"
                         data-start="0">
                    </div>

                    <!-- LAYER NR. 1 -->
                    <div class="tp-caption sfb fadeout text-right large_white"
                         data-x="right"
                         data-y="180"
                         data-speed="500"
                         data-start="1000"
                         data-easing="easeOutQuad">Whale and Dolpin Watching Closely
                    </div>	

                    <!-- LAYER NR. 2 -->
                    <div class="tp-caption sfb fadeout text-right large_white tp-resizeme hidden-xs"
                         data-x="right"
                         data-y="250"
                         data-speed="500"
                         data-start="1300"
                         data-easing="easeOutQuad"><div class="separator-3 light"></div>
                    </div>	

                    <!-- LAYER NR. 3 -->
                    <div class="tp-caption sfb fadeout medium_white text-right"
                         data-x="right"
                         data-y="270"
                         data-speed="500"
                         data-start="1300"
                         data-easing="easeOutQuad"
                         data-endspeed="600"><p class="object-visible">Whale and dolphin watching in Mirissa is one of the most exciting water activities<br> you can do in Sri Lanka during your holiday. Mirissa is the best place<br> to start your whale and dolphin watching tour in Sri Lanka.</p>
                    </div>

                    <!-- LAYER NR. 4 -->
                    <div class="tp-caption sfb fadeout small_white text-right hidden-xs"
                         data-x="right"
                         data-y="380"
                         data-speed="500"
                         data-start="1600"
                         data-easing="easeOutQuad"
                         data-endspeed="600"><a href="#" class="btn btn-dark btn-default btn-animated">Fun Times <i class="fa fa-arrow-right"></i></a> <a href="#" class="btn btn-dark btn-default btn-animated">Historical <i class="fa fa-arrow-right"></i></a> <a href="#" class="btn btn-dark btn-default btn-animated">Natuaral <i class="fa fa-arrow-right"></i></a>
                    </div>

                    <div class="tp-caption fade fadeout"
                         data-x="center"
                         data-y="bottom"
                         data-voffset="-100"
                         data-speed="500"
                         data-easing="easeOutQuad"
                         data-start="2000"
                         data-endspeed="200">
                        <a href="#hotel4" class="btn btn-lg moving smooth-scroll"><i class="icon-down-open-big"></i><i class="icon-down-open-big"></i><i class="icon-down-open-big"></i></a>
                    </div>
                </li>
                <!-- slide 3 end -->

                <!-- slide 4 start -->
                <!-- ================ -->
                <li data-transition="random-static" data-slotamount="7" data-masterspeed="500" data-saveperformance="on" data-title="Luxury Services">

                    <!-- main image -->
                    <img src="images/slides/medicalRepo.jpg" alt="slidebg4" data-bgposition="center top"  data-bgrepeat="no-repeat" data-bgfit="cover">

                    <!-- Transparent Background -->
                    <div class="tp-caption dark-translucent-bg"
                         data-x="center"
                         data-y="bottom"
                         data-speed="500"
                         data-easing="easeOutQuad"
                         data-start="0">
                    </div>

                    <!-- LAYER NR. 1 -->
                    <div class="tp-caption sfb fadeout large_white"
                         data-x="right"
                         data-y="70"
                         data-speed="500"
                         data-start="1000"
                         data-easing="easeOutQuad"
                         data-end="10000"> <span class="logo-font">Walawwawatta Resort</span><br> Best Services
                    </div>	

                    <!-- LAYER NR. 2 -->
                    <div class="tp-caption sfb fadeout text-left medium_white"
                         data-x="right"
                         data-y="200" 
                         data-speed="500"
                         data-start="1300"
                         data-easing="easeOutQuad"
                         data-endspeed="600">Beauty Spa Center <span class="icon default-bg circle small hidden-xs"><i class="fa fa-medkit"></i></span> 
                    </div>

                    <!-- LAYER NR. 3 -->
                    <div class="tp-caption sfb fadeout text-left medium_white"
                         data-x="right"
                         data-y="260" 
                         data-speed="500"
                         data-start="1600"
                         data-easing="easeOutQuad"
                         data-endspeed="600">Free WiFi area <span class="icon default-bg circle small hidden-xs"><i class="fa fa-wifi"></i></span> 
                    </div>

                    <!-- LAYER NR. 4 -->
                    <div class="tp-caption sfb fadeout text-left medium_white"
                         data-x="right"
                         data-y="320" 
                         data-speed="500"
                         data-start="1900"
                         data-easing="easeOutQuad"
                         data-endspeed="600">Car Parking and Pets Allowed <span class="icon default-bg circle small hidden-xs"><i class="fa fa-paw"></i></span> 
                    </div>

                    <!-- LAYER NR. 5 -->
                    <div class="tp-caption sfb fadeout text-left medium_white"
                         data-x="right"
                         data-y="380" 
                         data-speed="500"
                         data-start="2200"
                         data-easing="easeOutQuad"
                         data-endspeed="600">24-hour Room Service <span class="icon default-bg circle small hidden-xs"><i class="icon-check"></i></span> 
                    </div>

                    <!-- LAYER NR. 6 -->
                    <div class="tp-caption fade fadeout"
                         data-x="center"
                         data-y="bottom"
                         data-voffset="-100"
                         data-speed="500"
                         data-easing="easeOutQuad"
                         data-start="2000"
                         data-endspeed="200">
                        <a href="#hotel4" class="btn btn-lg moving smooth-scroll"><i class="icon-down-open-big"></i><i class="icon-down-open-big"></i><i class="icon-down-open-big"></i></a>
                    </div>
                </li>
                <!-- slide 4 end -->

            </ul>
            <div class="tp-bannertimer"></div>
        </div>
    </div>
    <!-- slider revolution end -->

</div>