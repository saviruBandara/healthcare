<!--
To change this license header, choose License Headers in Project Properties.
To change this template file, choose Tools | Templates
and open the template in the editor.
-->
<?php
try {
$pageKey = 'portal';
$CSS_FILE = 'toolbox';
?>

<?php include '' ?>

<?php
if ($usesess->statusAvailable == 1) {
//$PDO_fun=new PDOConnector();
$staffid = $PDO_fun->set
?>
<script type="text/javascript">
    jQuery(document).ready(function() {
    < % if (request.getParameter("menucat") != null) { % >
                var catmenu = "<%=request.getParameter("
        menucat")%>" ;
                jQuery('#submenu_bar ul li.ulid' + catmenu + " a").trigger('click') ;
    < %
        }
        % >
                jQuery('#submenu_bar ul li a').on('click' , function() {
            var urlhash = window.location.href ;
            var ulliid = jQuery(this).parent('li').attr('class').split(' ') ;
            var splitid = ulliid[0].replace("ulid" , "") ;
            if (urlhash.contains("&menucat=")) {
                urlhash = urlhash.slice(0 , -1) ;
                window.location.href = urlhash + splitid ;
            } else {
                urlhash = urlhash + "&menucat=" + splitid ;
                window.location.href = urlhash ;
            }
        }) ;
        }) ;</script>
<div class="main posrel" id="main" role="main">
    <div class="main-intro section-inner">
        <div id="submenu_bar" class="section-inner">
            <ul>
                <?php
                $subitem = 11;
                for ($i = 1;
                $i <= $subitem;
                $i++) {
                if ((user.getUserType().getUstId() == 3) && (i == 2 || i == 3 || i == 6 || i == 7 || i == 8 || i == 9 || i == 10 || i == 11)) {
                continue;
                } else if ((user.getUserType().getUstId() == 2) && (i == 5 || i == 9 || i == 10 || i == 11)) {
                continue;
                } else if ((user.getUserType().getUstId() == 1) && i == 5) {
                continue;
                } else {
                ?>
                <li class="ulid<%=i%> "><a href="#tabs-<%=i%>"><%=func.convertGlobalText(pageContext.getAttribute("pageKey").toString(), "tab" + i + "title", "htmlStrip")%></a></li>
                <%}
                }%>
            </ul>
            <div id="tabs-1" class="home subtabs editMe">
                <div class="editMeTable">
                    <% if (request.getAttribute("errbus") != null) {%>
                    <div id="dialog-message" title="errror" style="color: red;margin-bottom: 10px ">
                        <%if (request.getAttribute("errbus").equals("fnlen")) {%>
                        First Name Length too long
                        <%} else if (request.getAttribute("errbus").equals("lnlen")) {%>
                        Last Name Length too long
                        <%} else if (request.getAttribute("errbus").equals("townlen")) {%>
                        Town Name Length too long
                        <%}%>
                    </div>
                    <% }%>
                    <form name="buupdate" action="buupdate" enctype="multipart/form-data" method="post">
                        <div class="tr labelTest"><label>First Name :</label>
                            <input class="td labelremainse5 fname" disabled="true" type="text" required="true" name="fname" value="<%=users.getFname()%>">
                            <input class="checkEdit" data-key="fname" type="checkbox" name="fnameCH" value="ON" >
                        </div>
                        <div class="tr labelTest"><label>Last Name :</label>
                            <%if (users.getLname() != null) {%>
                            <input class="td labelremainse5 lname" disabled="true" data-type="lname" type="text" required="true" name="lname" value="<%=users.getLname()%>">
                            <input class="checkEdit" data-key="lname" type="checkbox" name="lanmeCH" value="ON" >
                            <%} else {%>
                            <input class="td labelremainse5" disabled="true" type="text" required="true" name="lname" value="Not Available%>">
                            <%}%>
                        </div>
                        <div class="tr labelTest"><label>Town</label>
                            <%if (users.getAddress() != null) {%>
                            <input class="td labelremainse5 town" disabled="true" type="text" required="true" name="town" value="<%=users.getAddress().getAdd2()%>">
                            <input class="checkEdit" data-key="town" type="checkbox" name="townCH" value="ON" />
                            <%} else {%>
                            <input class="td labelremainse5" disabled="true" type="text" disabled required="true" name="bname" value="Not Available">
                            <%}%>
                        </div>
                        <div class="tr labelTest"><label>Birth Date :</label>
                            <%if (users.getDatetimeByBday() != null) {%>
                            <input class="td labelremainse5 datepicker date" disabled="true" type="date" required="true" name="date" value="<%=users.getDatetimeByBday().getDate()%>">
                            <input class="checkEdit" data-key="date" type="checkbox" name="dateCH" value="ON" />
                            <%} else {%>
                            <input class="td labelremainse5" disabled="true" type="text" disabled required="true" name="date" value="Not Available">
                            <%}%>
                        </div>
                        <div class="tr labelTest"><label>Contact Numbers :</label>
                            <div class="twoField">
                                <%if (mobileno != null) {%>
                                <input class="td labelremainse5 mobile1" disabled="true" type="tel" required="true" name="phon1" value="<%=mobileno.getMobile1()%>">
                                <input class="checkEdit" data-key="mobile1" type="checkbox" name="mobile1CH" value="ON" />
                                <%} else {%>
                                <input class="td labelremainse5"  disabled="true" type="tel" required="true" name="phon1" disabled value="Not Available">
                                <%}
                                if (mobileno != null) {%>
                                <input class="td labelremainse5 mobile2" disabled="true" type="tel" required="true" name="phon2" value="<%=mobileno.getMobile2()%>">
                                <input class="checkEdit" data-key="mobile2" type="checkbox" name="mobile2CH" value="ON" />
                                <%} else {%>
                                <input class="td labelremainse5" disabled="true" type="tel" disabled required="true" name="phon2" value="Not Available">
                                <%}%>
                            </div>
                        </div>
                        <div class="tr labelTest"><label>Password :</label>
                            <div class="twoField">
                                <input class="td labelremainse5 passcur" disabled="true" type="password" required="true" name="pass" value="Enter New Password">
                                <input class="checkEdit" data-key="passcur" type="checkbox" name="passnewCH" value="ON" />
                                <input class="td labelremainse5 passcur oldpass" disabled="true" type="password" required="true" name="oldpass" value="Enter Current Password">
                            </div>
                        </div>
                        <button class="proSave"><%=func.convertGlobalText(pageContext.getAttribute("pageKey").toString(), "proUpdateText", "htmlStrip")%></button>
                    </form>
                </div>   
            </div>
            <%if (user.getUserType().getUstId() == 3) {%>
            <div id="tabs-5" class="home subtabs history">
                <div id="checkouts">
                    <table>
                        <thead>
                        <td>QUANTITY</td>
                        <td>COST</td>
                        <td>Buyer</td>
                        <td>SELLER</td>
                        <%if (user.getUserType().getUstId() == 2) {%>
                        <td>DElIVERY STATUS</td>
                        <%}%>
                        </thead>
                        <tbody>
                            <%
                            List<Checkout> chk = null;
                            if (user.getUserType().getUstId() == 2) {
                            chk = pagesess.createCriteria(Checkout.class).add(Restrictions.eq("seller", user.getUid())).list();
                            } else if (user.getUserType().getUstId() == 3) {
                            chk = pagesess.createCriteria(Checkout.class).add(Restrictions.eq("buyer", user.getUid())).list();
                            System.out.print("awadooo sansare");
                            }
                            if (chk != null) {
                            System.out.print(chk.size());
                            for (Checkout chkout : chk) {
                            Users buyUser = (Users) pagesess.load(Users.class, chkout.getBuyer());
                            Users sellUser = (Users) pagesess.load(Users.class, chkout.getSeller());

                            %>
                            <tr>
                                <td><%=chkout.getQuantity()%></td>
                                <td><%=chkout.getAmount()%></td>
                                <td><%=buyUser.getFname()%></td>
                                <td>seller</td>
                                <%if (user.getUserType().getUstId() == 2) {%>
                                <td><%=(chkout.getSolutionsStatus().getIdsolution() == 1) ? "DELIVERED" : "NOT DELIVERED"%></td>
                                <%}%>
                            </tr>
                            <%}
                            } else {%>
                            No Checkouts
                            <%} %> 
                            </tbody>
                    </table>
                </div>              
            </div>
            <%}
            if (user.getUserType().getUstId() == 1 || user.getUserType().getUstId() == 2) {%>
            <div id="tabs-2" class="home subtabs products">
                <div id="shop">
                    <span id="errormsg"></span>
                    <%  if (request.getAttribute("seccatwrong") != null) {%>
                    <span>   Selected sector and category are out of structure </span>
                    <% }
                    if (request.getAttribute("errprosav1") != null) {%>
                    <div class="labelremainse51" style="color:red">
                        <%if (request.getAttribute("errprosav1").equals("titlen")) {%>
                        <label>Length of title is too long...</label>
                        <%} else if (request.getAttribute("errprosav1").equals("desclen")) {%>
                        <label>Description is  too long...</label>
                        <%} else if (request.getAttribute("errprosav1").equals("bnlen")) {%>
                        <label>Your name too long ...</label>
                        <%} else if (request.getAttribute("errprosav1").equals("imglen")) {%>
                        <label>Image name is too long...</label>
                        <%} else if (request.getAttribute("errprosav1").equals("brandlen")) {%>
                        <label>Brand name is too long...</label>
                        <%} else if (request.getAttribute("errprosav1").equals("inval")) {%>
                        <label>Invalid entry...</label>
                        <%} else if (request.getAttribute("errprosav1").equals("pricelen")) {%>
                        <label>Data too long...</label>
                        <%} else if (request.getAttribute("errprosav1").equals("framesize")) {%>
                        <label>frame size out of range...</label>
                        <%} else if (request.getAttribute("errprosav1").equals("phonLet")) {%>
                        <label>width and height should be in numbers...</label>
                        <%} else if (request.getAttribute("errprosav1").equals("namelen")) {%>
                        <label>name is too long...</label>
                        <%} else if (request.getAttribute("errprosav1").equals("S")) {%>
                        <label>Entered Sector and Category out of Structure...</label>
                        <% }
                        %>
                    </div>
                    <% }%>
                    <form action="ProSav" method="post" onsubmit="return formvalch() ;" name="prosav" enctype="multipart/form-data">
                        <div>
                            <table>
                                <tr>
                                    <td><label>Product Name:</label></td>
                                    <td><input maxlength="50" id="prname" required="required" class="labelremainse5" type="text" name="prodname" value="" /></td>
                                </tr>
                                <tr>
                                    <td><label>Price of the product:</label></td>
                                    <td><input maxlength="15" onkeydown="return inputchk(event)"  id="prprice" required="required" class="labelremainse5" type="text" name="propri" value="" /></td>
                                </tr>
                                <tr>
                                    <td><label>Publisher of the product:</label></td>
                                    <td><input maxlength="50" id="prbrand" required="required" class="labelremainse5" type="text" name="brand" value="" /></td>
                                </tr>
                                <tr>
                                    <td><label>Category of the product:</label></td>
                                    <td> 
                                        <select name="catcd" class="labelremainse5" required="required">
                                            <%
                                            List<BusiCategory> busicat = pagesess.createCriteria(BusiCategory.class).list();
                                                for (BusiCategory bus : busicat) {
                                                %>
                                                <option value="<%=bus.getBusiCategoryid()%>"><%=bus.getCateName()%></option>
                                                <% }  %>
                                        </select> 
                                    </td>                      
                                </tr><tr>
                                    <td><label id="prdes" required="required" >Description:</label></td>
                                    <td><textarea class="labelremainse5" name="budes" rows="7" cols="10">
                                        </textarea></td>
                                </tr>
                                <tr>
                                    <td><label id="prdes" required="required" >Upload an image</label></td>
                                    <td><input class="labelremainse5" required="required" type="file"  value="Browse a image" name="proimg" />
                                        <input class="labelremainse5" type="file"  value="Browse a image" name="proimg1" />
                                        <input class="labelremainse5" type="file"  value="Browse a image" name="proimg2" />
                                        <input class="labelremainse5" type="file"  value="Browse a image" name="proimg3" /></td>
                                </tr>
                            </table>
                        </div>
                        <div>
                            <button class="proSave">Add to product list</button>
                        </div>
                    </form>
                    <hr>
                    <div >
                        <%  Criteria producrsearch = pagesess.createCriteria(Books.class);
                        List<Books> listpro = producrsearch.add(Restrictions.eq("users.uid", userid)).list();
                            int prsize = listpro.size();

                            %>
                            <div>
                                <label>PRODUCT LIST</label>
                                <span><%="  -  " + prsize + "   Products found -- "%></span>
                                <hr>
                                <div>
                                    <label>Sort by sector:</label>
                                    <input type="radio" name="1" value="0" onclick="sortbysec(value) ;" /> All
                                    <%
                                    for (BusiCategory busi : busicat) {
                                    %>
                                    <input type="radio" name="1" value="<%=busi.getBusiCategoryid()%>" onclick="sortbysec(value) ;"/> <%=busi.getCateName().toUpperCase()%>
                                    <%}%>
                                </div>
                            </div>
                            <hr>
                            <div  class="productStuct" id="hit">
                                <%
                                for (int i = 0; i < listpro.size(); i++) {
                                Books sep = listpro.get(i);
                                Bookdetails sep1 = (Bookdetails) pagesess.load(Bookdetails.class, sep.getBookdetails().getProdetid());
                                %>
                                <div class="prdItem" data-key="<%=sep1.getBusiCategory().getBusiCategoryid()%>">
                                    <div class="primage"><img src="<%=sep.getImage()%>"  width="360" height="150"/>
                                    </div>
                                    <div class="content">
                                        <h4><%=sep.getPname()%></h4>
                                        <div class="otherDetails">
                                            <div class="description">
                                                <%=sep1.getProductDescription()%>
                                            </div>
                                            <div class="bottomBar">
                                                <a class="price">$ <%=sep1.getPrice().intValue()%></a>
                                                <a class="more">
                                                    <form action="viewItem.jsp">
                                                        <input type="hidden" name="product" value="<%=sep.getPid()%>" />
                                                        <input type="hidden" name="productDetails" value="<%=sep1.getProdetid()%>" />
                                                        <button type="submit"><%=new function().convertGlobalText(pageContext.getAttribute("pageKey").toString(), "moreText", "htmlStrip")%></button>
                                                    </form>
                                                </a>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <%
                                }
                                %>
                            </div>
                    </div>
                </div>
            </div>
            <div id="tabs-3" class="home subtabs adds">
                <div id="ad">
                    <form action="ProSav1" method="post" enctype="multipart/form-data" id="prosav1">
                        <div class="addForm">
                            <div class="inputrow">
                                <label>Select a add type:</label>
                                <div class="rowRight">
                                    <select name="addtype" class="labelremainse5" required="required">
                                        <%
                                        Criteria crt = pagesess.createCriteria(AddTypes.class);
                                        List<AddTypes> addlist = crt.list();
                                            for (AddTypes adty : addlist) {
                                            %>
                                            <option  value="<%=adty.getIdaddTypes()%>"><%=adty.getAddType()%></option>
                                            <%}%>
                                    </select>
                                </div>
                            </div>
                            <div class="inputrow">
                                <label>Enter a title:</label>
                                <div class="rowRight">
                                    <input required="required" class="labelremainse5"  type="text" placeholder="Enter a title" name="title" id="title">
                                </div>
                            </div>
                            <div class="inputrow">
                                <label>Enter a Description:</label>
                                <div class="rowRight">
                                    <textarea name="desc" rows="7" cols="50" required="required" class="labelremainse5" id="descrip"></textarea>
                                </div>
                            </div>
                            <div class="inputrow">
                                <label>Select a image:</label>
                                <div class="rowRight">
                                    <input required="required" class="labelremainse5"  type="file" value="Browse Image" name="img">
                                </div>
                            </div>
                        </div>
                        <button>Publish</button>
                    </form>
                    <hr>
                    <div>
                        <%
                        Criteria addsearch = null;
                        int addprsize = 0;
                        int usid = Integer.parseInt(session.getAttribute("logmsg").toString());
                        Users usa = null;
                        List<Adds> addlistpro = null;
                            addsearch = pagesess.createCriteria(Adds.class);
                            usa = (Users) pagesess.load(Users.class, usid);
                            addlistpro = addsearch.add(Restrictions.eq("users.uid", usid)).list();
                            addprsize = addlistpro.size();

                            %>
                            <label>PRODUCT LIST <%="  - - " + addprsize + "   Posts found -- "%></label>
                            <hr>
                            </div>
                            <hr>
                            <div class="productStuct" id="hitadd">
                                <%      if (addlistpro != null) {
                                for (int i = 0; i < addlistpro.size(); i++) {
                                Adds sep = addlistpro.get(i);
                                //PostDesign totlist = (PostDesign) pagesess.load(PostDesign.class, sep.getPostDesign().getIdpostDesign());
                                %>
                                <div class="prdItem">
                                    <div class="primage"><img src="<%=sep.getAddimg()%>"  width="360" height="150"/></div>
                                    <div class="content">
                                        <h6><%=sep.getUsers().getFname()%></h6>
                                        <h4><%=sep.getTitle()%></h4>
                                        <div class="otherDetails">
                                            <div class="bottomBar">
                                                <a class="more" href="promotions/<%=usa.getFname().toLowerCase().replaceAll("\\s", "") + "-" + sep.getTitle().toLowerCase().replaceAll("\\s", "") + sep.getIdAdds()%>">
                                                   <%=new function().convertGlobalText(pageContext.getAttribute("pageKey").toString(), "moreText", "htmlStrip")%>
                                            </a>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <%}
                            }%>
                        </div>
                </div>
            </div>
            <div id="tabs-6" class="home subtabs miniadds">
                <div id="ad">
                    <%if (request.getAttribute("miniaddssucmsg") != null) {%>
                    <div class="labelremainse51" style="color:red">
                        <%if (request.getAttribute("miniaddssucmsg").equals("no")) {%>
                        <label>Length of description is too long...</label>
                        <%}%>
                    </div>
                    <%}
                    int miniaddscount = 15;
                    List<MiniAdds> minicri = pagesess.createCriteria(MiniAdds.class).list();
                        for (MiniAdds mini : minicri) {
                        %>
                        <div class="prdItem">
                            <form action="miniadd" method="post">
                                <input type="hidden" name="miniaddid" value="<%=mini.getIdminiAdds()%>" />
                                <textarea name="minidesc" maxlength="60" placeholder="Enter new description to update(<60 words)">
                                    Enter new description to update(<60 words).
                                </textarea>
                                <input type="submit" value="Enter" /><br>
                                <label>Current Text</label>
                                <textarea maxlength="60" disabled="disabled">
                                <%=mini.getMiniAddescription()%>
                                </textarea>
                                <label class="labelTest">MiniAdd NO: <%=mini.getIdminiAdds()%></label>
                            </form>
                        </div>
                        <%}%>
                </div>
            </div>
            <div id="tabs-7" class="home subtabs pageContent">
                <div id="ad">
                    <table>
                        <thead>
                        <th> <select name="loca" class="locationSel" onchange="toollocation(this)">
                                <%
                                List<Cms> listcms = pagesess.createQuery("select distinct globalName from Cms").list();
                                    for (int d = 0; d < listcms.size(); d++) {
                                    %>
                                    <option data-cmstit="<%=listcms.get(d)%>"><%=listcms.get(d)%></option>
                                    <%}%>
                            </select> </th>
                        <th>Parent Block</th>
                        <th>Html Type</th>
                        </thead>
                        <tbody>
                            <%
                            List<Cms> cms = pagesess.createCriteria(Cms.class).list();
                            for (Cms cmsitem : cms) {%>
                            <tr class="rsCarousel <%=cmsitem.getGlobalName()%> <%=(cmsitem.getGlobalName().equals("mainNavigation") ? "" : "displaynone")%>">
                                <td><%=cmsitem.getGlobalName() != null ? cmsitem.getGlobalName() : cmsitem.getPageKey()%></td>
                                <%// if (cmsitem.getHtmlType().equals("htmlStrip")) {%>
                                <td class="dotted <%=(cmsitem.getDescription() == null) ? "nullValue" : ""%>" >
                                    <a href="#popupForm-<%=cmsitem.getIdCms()%>"> <%=(cmsitem.getDescription() != null) ? cmsitem.getDescription() : cmsitem.getItemName()%> </a>
                                    <div class="popupWrapper">
                                        <form class="popup" id="popupForm-<%=cmsitem.getIdCms()%>" >
                                            <div class="topbar">
                                                <label>Location:<%=cmsitem.getGlobalName() != null ? cmsitem.getGlobalName() : cmsitem.getPageKey()%>|</label>
                                                <label>Item:<%=cmsitem.getItemName()%>|</label>
                                                <label>Type:<%=cmsitem.getHtmlType()%></label>
                                            </div>
                                            <input type="text" class="itemText" placeholder="<%=(cmsitem.getDescription() != null) ? cmsitem.getDescription() : cmsitem.getItemName()%>"/>
                                            <input type="hidden" class="location" value="<%=cmsitem.getGlobalName() != null ? cmsitem.getGlobalName() : cmsitem.getPageKey()%>"/>
                                            <input type="hidden" class="htmlType" value="<%=cmsitem.getHtmlType()%>"/>
                                            <input type="hidden" class="itemName" value="<%=cmsitem.getItemName()%>"/>
                                            <button type="button" class="subPop">Enter</button>
                                        </form>
                                    </div>
                                </td>
                                <% //} else { %>

                                <% //}%>
                                <td><%=cmsitem.getHtmlType()%></td>
                            </tr>
                            <%
                            }
                            %>
                            </tbody> 
                    </table>
                </div>
            </div>
            <div id="tabs-8" class="home subtabs mediaManager">
                <div id="uploadArea">
                    <select class="uploadObject " onchange="obectChanege()">
                        <option value="0">select a widget</option>
                        <%  List<Mediaobject> listmedia = pagesess.createCriteria(Mediaobject.class).list();
                            for (Mediaobject med : listmedia) {
                            %>
                            <option value="<%=med.getIdmediaObject()%>"><%=med.getMediaName()%></option>
                            <% } %>
                    </select>
                    <img id="itemImage" src="" />
                    <form action="mediaManager1" method="post" class="addimg">
                        <input id="imghref" required="required" type="hidden" name="imghref" value="" />
                        <input id="objName" required="required" type="hidden" name="objName" value="" />
                        <input type="submit" value="Add image" />
                    </form>
                    <form action="mediaManager" enctype="multipart/form-data" method="post" class="saveimg">
                        <input class="file" type="file" required name="find" value="" />
                        <input type="submit" value="save file" />
                    </form>
                </div>
                <%
                if (request.getParameter("putset") != null) {
                String uistatus = request.getParameter("putset");%>
                <div class="ui-state-highlight ui-corner-all" style="margin-top: 20px; padding: 0 .7em;">
                    <p><span class="ui-icon ui-icon-info" style="float: left; margin-right: .3em;"></span>
                        <strong>Hey! <% if (uistatus.equals("succ")) { %>Your file was created.<%}%></strong>
                    </p>        
                </div>
                <% } else if (request.getParameter("removeThumb") != null) {
                String encode = request.getParameter("removeThumb");
                String encodeid[] = encode.split("#");
                int removeid = Integer.parseInt(encodeid[0]);
                Transaction trupc = pagesess.beginTransaction();
                Mediamanager mediaid = (Mediamanager) pagesess.load(Mediamanager.class, removeid);
                SolutionsStatus sta = (SolutionsStatus) pagesess.load(SolutionsStatus.class, 2);
                mediaid.setSolutionsStatus(sta);
                pagesess.update(mediaid);
                trupc.commit();
                %>
                <div class="ui-state-highlight ui-corner-all" style="margin-top: 20px; padding: 0 .7em;">
                    <p><span class="ui-icon ui-icon-info" style="float: left; margin-right: .3em;"></span>
                        <strong>Image has been send to trash....  you can restore if u want</strong>
                    </p>        
                </div>
                <%}%>
                <div id="imageViewer">
                    <% List<Mediamanager> mm = pagesess.createCriteria(Mediamanager.class).list();
                        for (Mediamanager sin : mm) {
                        if (sin.getSolutionsStatus().getIdsolution() == 1) {
                        %>
                        <div class="fileItem">
                            <a class="imagehref <%=sin.getIdmediaManager()%>" id="<%=sin.getMediaManagercol()%>"><img width="150" height="100px" src="<%=sin.getMediaManagercol()%>" title="<%=sin.getMediaManagercol()%>" /></a>
                            <a href="home.jsp?active=2&removeThumb=<%=sin.getIdmediaManager()%>#<%=System.currentTimeMillis()%>" class="delbutton"></a>
                        </div>  
                        <%                        }
                        }%>

                </div>
            </div>

            <% }
            if (user.getUserType().getUstId() == 1) {%>
            <div id="tabs-9" class="home subtabs userManagement">
                <div id="ad">
                    <fieldset >
                        <legend class="labelremainse5">USER LOG</legend>
                        <div class="topbar">
                            <input type="text" name="findid" class="inputStyle" />
                            <input class="labelTest" type="radio" name="leg" value="byname" checked="" />BY NAME
                            <input class="labelTest" type="radio" name="leg" value="byemail" />BY EMAIL
                            <input class="labelTest" type="radio" name="leg" value="byday" />BY B'DAY
                        </div><hr>
                        <div class="leftbar">
                            <label>First Name</label>
                            <label>Last Name</label>
                            <label>Email</label>
                            <label>Phone</label>
                            <label>Status</label>
                            <label>Age</label>
                        </div>
                        <div class="rightbar">
                            <img src="" width="100" height="100" />
                        </div>
                    </fieldset>
                </div>
            </div>
            <div id="tabs-10" class="home subtabs deliveryMng">
                <%--        
                <div id="toolaccordion">
                    <%
                    List<Checkout> chk = pagesess.createCriteria(Checkout.class).list();
                        for (Checkout chkout : chk) {
                        Users buyUser = (Users) pagesess.load(Users.class, chkout.getBuyer());
                        Users sellUser = (Users) pagesess.load(Users.class, chkout.getSeller());
                        Product happyprd = (Product) pagesess.load(Product.class, chkout.getProduct().getPid());

                        %>
                        <h3>
                            Product Name-<%=happyprd.getPname()%> | BusinessUser- <%=sellUser.getBname()%> | SmartUser-<%=buyUser.getFname()%> | 
                            <%if (chkout.getSolutionsStatus().getIdsolution() == 1) {%>
                            DELIVERED
                            <%} else {%>
                            Still Not Delivered
                            <%}%>
                        </h3>
                        <div>
                            <div class="left msgcon">
                                <div class="subLeft">
                                    <label class="labelremainse5">Quantity-<%=chkout.getQuantity()%></label><br>
                                    <label class="labelremainse5">Price-<%=chkout.getAmount()%></label><br>
                                    <label class="labelremainse5">Brand-<%=happyprd.getBrand().getBrandName()%></label><br>
                                </div>
                                <div class="subLeft">
                                    <label class="labelremainse5">Delivery Address-<br><%=chkout.getShippingdetail().getDeliverAddress()%></label>
                                </div>
                            </div>
                            <div class="right msgcon">
                                <%if (chkout.getSolutionsStatus().getIdsolution() != 1) {%>
                                <form action="toolbox.jsp" method="post">
                                    <input type="hidden" value="<%=chkout.getIdchkout()%>" name="deliverstatus" >
                                    <button type="submit">Proceed</button>
                                </form>
                                <%}%>
                                <img width="200" height="100" src="<%=happyprd.getImage()%>"/>
                            </div>   
                        </div>
                        <%}%>
                </div>
                --%>
                <%--
                <table>
                    <thead>
                    <th> <select name="loca" class="locationSel" onchange="userlocation(this)">
                            <%
                            List<UserType> listusety = pagesess.createCriteria(UserType.class).list();
                                for (UserType ustid : listusety) {
                                %>
                                <option data-uredi="<%=ustid.getUstId()%>"><%=ustid.getUserType()%></option>
                                <%}%>
                        </select> 
                    </th>
                    <th>User Name</th>
                    <th>Status</th>
                    </thead>
                    <tbody>
                        <%
                        if (request.getParameter("uiddis") != null) {
                        Users disableuser = (Users) pagesess.load(Users.class, Integer.parseInt(request.getParameter("uiddis")));
                        Transaction distra = pagesess.beginTransaction();
                        disableuser.setStatus((Status) pagesess.load(Status.class, 2));
                        pagesess.update(disableuser);
                        distra.commit();
                        } else if (request.getParameter("uienabis") != null) {
                        Users disableuser = (Users) pagesess.load(Users.class, Integer.parseInt(request.getParameter("uienabis")));
                        Transaction distra = pagesess.beginTransaction();
                        disableuser.setStatus((Status) pagesess.load(Status.class, 1));
                        pagesess.update(disableuser);
                        distra.commit();
                        }
                        List<Users> listuse = pagesess.createCriteria(Users.class).list();
                        for (Users cmsitem : listuse) {%>
                        <tr class="rsCarousel <%=cmsitem.getUserType().getUserType()%>">
                            <td><%=cmsitem.getUid()%></td>
                            <td><%=(cmsitem.getBname() != null) ? cmsitem.getBname() : cmsitem.getFname()%></td>
                            <td>
                                <% if (cmsitem.getUserType().getUstId() != 1) {
                                if (cmsitem.getStatus().getStatid() == 1) {%>
                                <form action="toolbox.jsp" method="post">
                                    <input type="hidden" value="<%=cmsitem.getUid()%>" name="uiddis"/>
                                    <button>Disable</button>
                                </form>
                                <%} else {%>
                                <form action="toolbox.jsp" method="post">
                                    <input type="hidden" value="<%=cmsitem.getUid()%>" name="uienabis"/>
                                    <button>Enable</button>
                                </form>
                                <%}
                                }%>
                            </td>
                        </tr>
                        <%}%>
                        </tbody> 
                </table>
                --%>
            </div>
            <div id="tabs-11" class="home subtabs bookMng">
                <%--
                <table>
                    <thead>
                    <th>Product ID</th>
                    <th>Product Name</th>
                    <th>Product Brand</th>
                    <th>URL</th>
                    <th>Status</th>
                    </thead>
                    <tbody>
                        <%
                        if (request.getParameter("prdouctddis") != null) {
                        Product disableuser = (Product) pagesess.load(Product.class, Integer.parseInt(request.getParameter("prdouctddis")));
                        Transaction distra = pagesess.beginTransaction();
                        disableuser.setStatus((Status) pagesess.load(Status.class, 1));
                        pagesess.update(disableuser);
                        distra.commit();
                        } else if (request.getParameter("productenabis") != null) {
                        Product disableuser = (Product) pagesess.load(Product.class, Integer.parseInt(request.getParameter("productenabis")));
                        Transaction distra = pagesess.beginTransaction();
                        disableuser.setStatus((Status) pagesess.load(Status.class, 2));
                        pagesess.update(disableuser);
                        distra.commit();
                        }
                        List<PublishShop> listproducts = pagesess.createCriteria(PublishShop.class).list();
                        for (PublishShop cmsitem : listproducts) {
                        String url = "/jspFinal/products/" + cmsitem.getProduct().getPname().toLowerCase().replaceAll("\\s", "") + cmsitem.getProduct().getPid();
                        %>
                        <tr class="rsCarousel">
                            <td><%=cmsitem.getProduct().getPid()%></td>
                            <td><%=cmsitem.getProduct().getPname()%></td>
                            <td><%=cmsitem.getProduct().getBrand().getBrandName()%></td>
                            <td><a href="<%=url%>"><%=cmsitem.getProduct().getPname()%></a></td>
                            <td>
                                <% if (cmsitem.getProduct().getStatus().getStatid() == 2) {%>
                                <form action="toolbox.jsp" method="post">
                                    <input type="hidden" value="<%=cmsitem.getProduct().getPid()%>" name="prdouctddis"/>
                                    <button>Enable</button>
                                </form>
                                <%} else {%>
                                <form action="toolbox.jsp" method="post">
                                    <input type="hidden" value="<%=cmsitem.getProduct().getPid()%>" name="productenabis"/>
                                    <button>Disable</button>
                                </form>
                                <%}
                                %>
                            </td>
                        </tr>
                        <%}%>
                        </tbody> 
                </table>
                --%>
            </div>
            <%}%>
            <div id="tabs-4" class="home subtabs messages">
                <div id="accordion">
                    <%
                    List<Message> listmsg = pagesess.createCriteria(Message.class).add(Restrictions.eq("usersByUsersUid.uid", user.getUid())).list();
                        for (Message msg : listmsg) {
                        %>
                        <h3>Message Type : <%=msg.getMsgstat().getStatus()%> |
                            Date : <%=msg.getDatetime().getDate()%> | Time : <%=msg.getDatetime().getTime()%> 
                            <%=(msg.getMsgstat().getIdmsgstat() == 1 || msg.getMsgstat().getIdmsgstat() == 6) ? "<span class=\"notSeen\">UNREAD Message</span>" : ""%></h3>
                        <div>
                            <div class="left msgcon">
                                <%=msg.getMescontent()%>
                            </div>
                            <div class="right msgcon">
                                <form action="home.jsp" method="post">
                                    <input type='hidden' name='MsgID' value='<%=msg.getIdmessage()%>' />
                                    <textarea required="true" class="labelremainse5" name="budes" rows="7" cols="47"></textarea>
                                    <button type="submit">Enter</button>
                                </form>
                            </div>   
                        </div>
                        <%}%>
                </div>
            </div>
        </div>



        <div class="main posrel" id="main" role="main">
                <?php $items = array("mediamanager", "pagecontent", "usermanagement", ); ?>
            <div class="section-hor section-inner">
                <?php
                foreach ($items as $value) {
                ?>
                <a href="toolbox.php?toolitem=<?= urlencode("{$value}") ?>" class="item-tool <?= $value ?>" style="background:#666 url(../images/<?= $value ?>)"></a>
                <?php
                }
                ?>
            </div>
            <div id="main-content" class="main-intro section-wrapper">
                <?php
                if (isset($_REQUEST["toolitem"])) {
                $toolitem = $_REQUEST["toolitem"];
                if ($toolitem === "mediamanager") {
                redirect("./view/mediaManager.php");
                } elseif ($toolitem === "pagecontent") {
                ?>
                <h1 class="main-title">!+ TEXT #pageKey <?= $toolitem ?>metaH1 htmlStrip editMeta +!</h1>
                <table>
                    <thead>
                    <th>Text Position</th>
                    <th>Parent Block</th>
                    <th>Html Type</th>
                    </thead>
                    <tbody>
                        <?php
                        $cmsitems = $PDO_fun->getValue("select * from cms");
                        while ($row = $cmsitems->fetchObject()) {
                        ?>
                        <tr>
                            <td><?= !empty($row->globalName) ? $row->globalName : $row->page_key ?></td>
                            <td class="clicktd"><?= $row->itemName ?></td>
                            <td><?= $row->htmlType ?></td>
                        </tr>
                        <?php
                        }
                        ?>
                    </tbody> 
                </table>
                <?php
                }
                }
                ?>
            </div>
        </div> <!-- main -->

        <?php
        } else {
        redirect((isset($_SERVER["HTTP_REFERER"]) ? $_SERVER["HTTP_REFERER"] : "index.php"));
        }
        ?>
        <?php require 'inc.bodyBottom.php' ?>
        <?php
        } catch (Exception $exc) {
        redirect("../view/404.php");
        }
        ?>
