<?php

try {

    require_once './function.php';
    require_once '../model/PDOConnector.php';
?>
    <?php

    if (isset($_POST["email"]) && isset($_POST["pass"])) {
        $username = (String) $_POST["email"];
        $password = (String) $_POST["pass"];
        $PDO_fun = new PDOConnector();
        $query = "select * from login where uname=\"{$username}\" and password=\"{$password}\"";
        $val = $PDO_fun->getValue($query);
        echo $val->rowCount();
        if ($val->rowCount() >= 1) {
            $row = $val->fetch();
            if (isset($_POST["remind"])) {
                setcookie("username", $username, time() + 60 * 60 * 24 * 30);
                setcookie("password", md5($password), time() + 60 * 60 * 24 * 30);
            }
            $query1 = "select * from staff where idstaff={$row->staffid}";
            $userDet = $PDO_fun->getValue($query1);
            $row1 = $userDet->fetch();
            if ($row1->statusAvailable == 1) {
                session_start();
                $_SESSION["logmsg"] = $row1;
                redirect("../profile.php");
            } elseif ($row1->status_statid == 2) {
                redirect("../index.php?uiStatus=deactivate");
            } elseif ($row1->status_statid == 3) {
                redirect("../index.php?uiStatus=emailLink");
            }
        } else {
            redirect("../index.php?uiStatus=invalid");
        }
    } else {
        redirect("../index.php");
    }
} catch (Exception $exc) {
    redirect("../404.php");
}
    ?>