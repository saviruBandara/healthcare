<?php

class CMSfunctions {
    
}
