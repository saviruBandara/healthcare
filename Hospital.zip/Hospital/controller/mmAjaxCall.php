<?php
require_once '../model/PDOConnector.php';

if (isset($_REQUEST["ID"])) {
    $intid = (int) $_REQUEST["ID"];
//            if (intid == 0) {
//                List<Mediamanager> mmn = sess.createCriteria(Mediamanager.class).list();
//                for (Mediamanager mmn1 : mmn) {
//                    if (mmn1.getSolutionsStatus().getIdsolution() == 1) {
//                        String obj = "<div class=\"fileItem\"> <a class=\"imagehref " + mmn1.getIdmediaManager() + " \" id=\"" + mmn1.getMediaManagercol() + "\">";
//                        obj += "<img width=\"150\" height=\"100px\" src=\"" + mmn1.getMediaManagercol() + "\" title=\"" + mmn1.getMediaManagercol() + "\"/></a>";
//                        obj += "<a href=\"mediaManager.jsp?removeThumb=" + mmn1.getIdmediaManager() + "#" + System.currentTimeMillis() + "\" class=\"delbutton\"></a></div>";
//                        out.print(obj);
//                    }
//                }
//            } else {
//                List<MediaobjectHasMediamanager> mmn = sess.createCriteria(MediaobjectHasMediamanager.class).add(Restrictions.eq("mediaobject.idmediaObject", intid)).list();
//                for (MediaobjectHasMediamanager mmn1 : mmn) {
//                    if (mmn1.getMediamanager().getSolutionsStatus().getIdsolution() == 1) {
//                        String obj = "<div class=\"fileItem\"> <a class=\"imagehref " + mmn1.getMediamanager().getIdmediaManager() + " \" id=\"" + mmn1.getMediamanager().getMediaManagercol() + "\">";
//                        obj += "<img width=\"150\" height=\"100px\" src=\"" + mmn1.getMediamanager().getMediaManagercol() + "\" title=\"" + mmn1.getMediamanager().getMediaManagercol() + "\"/></a>";
//                        obj += "<a href=\"mediaManager.jsp?removeThumb=" + mmn1.getMediamanager().getIdmediaManager() + "#" + System.currentTimeMillis() + "\" class=\"delbutton\"></a></div>";
//                        out.print(obj);
//                    }
//                }
//            }
} else if (isset($_REQUEST["editText"]) && $_REQUEST["editText"] != null) {
    $htmltype = $_REQUEST["htmltype"];
    $itemtext = (String)$_REQUEST["itemText"];
    $itemName = $_REQUEST["itemName"];
    $location = $_REQUEST["location"];
    $PDO_fun = new PDOConnector();
    $query="select * from cms where itemName='$itemName' and pageKey='$location'";
    $searchResult = $PDO_fun->getValue($query)->fetch();
    if (!empty($searchResult) && isset($searchResult)) {
        $insertStatement="update cms set globalName='$itemtext' where idcms=$searchResult->idcms";
        if(($htmltype == "htmlNone" || $htmltype=="htmlStrip") && strlen($itemtext) < 50) {
            $PDO_fun->setValue($insertStatement);
        } elseif ($htmltype == "htmlAllow" && strlen($itemtext) < 1000) {
            $PDO_fun->setValue($insertStatement);
        } else {
            echo "Reduce the length of the text";
        }
    }else{
        echo "No result found";
    }
} else {
    echo "Dont hack me";
}