<?php

try {

    class Users {

        private $userid;
        private $fname;
        private $lname;
        private $nic;
        private $address;
        private $proImage;
        private $bDay;
        private $position;

        public function __construct($userid, $fname, $lname, $bname) {
            $this->userid = $userid;
            $this->fname = $fname;
            $this->lname = $lname;
            $this->nic = $bname;
        }

        public function setfname($value) {
            $this->fname = $value;
        }

        public function setlname($value) {
            $this->lname = $value;
        }

        public function setgender($value) {
            $this->nic = $value;
        }

        public function setbday($value) {
            $this->bDay = $value;
        }

        public function setproImg($param) {
            $this->proImage = $param;
        }

        public function setusttype($param) {
            $this->positions = $param;
        }

        public function setaddress($param) {
            $this->address = $param;
        }

        public function getaddress() {
            return $this->address;
        }

        public function getproImg() {
            return $this->proImage;
        }

        public function getusttype() {
            return $this->ust_type;
        }

        public function getcovImg() {
            return $this->proImage;
        }

        public function getfname() {
            return $this->firstname;
        }

        public function getlname() {
            return $this->lastname;
        }

        public function getgender() {
            return $this->gender;
        }

        public function getUID() {
            return $this->userid;
        }

        public function getbday() {
            return $this->bday;
        }

    }

    class Address {

        private $addid;
        private $add;
        private $country;

        public function __construct($addid, $ad1, $cou_id) {
            $this->addid = $addid;
            $this->add = $ad1;
            $this->country = (object) $cou_id;
        }

        public function setadd($param) {
            $this->add = $param;
        }

        public function setcountry($param) {
            $this->country = $param;
        }

        public function getadd() {
            return $this->add;
        }

        public function getcountry() {
            return $this->country;
        }
        

    }

    class Country {

        private $couid;
        private $name;

        public function __construct($cid, $name) {
            $this->couid = $cid;
            $this->name = $name;
        }

        public function setCouname($param) {
            $this->name = $param;
        }

        public function getCouname() {
            return $this->name;
        }

    }

    class Login {

        private $logid;
        private $uname;
        private $pass;
        private $userid;

        public function __construct($uname, $pass, $usid) {
            $this->uname = $uname;
            $this->pass = $pass;
            $this->userid = $usid;
        }

        public function getuname() {
            return $this->uname;
        }

        public function getpass() {
            return $this->pass;
        }

        public function getusid() {
            return $this->userid;
        }

    }

} catch (Exception $exc) {
    redirect("../404.php");
}
?>