
<?php

require_once 'classFile.php';

function redirect($newLocation) {
    header("Location:" . $newLocation);
    exit();
}

function convertText($pageid, $itemName, $htmlType) {
    try {
        $PDO_fun = new PDOConnector();
        $finalResult = "!+ {$pageid} {$itemName} {$htmlType} +!";
        $query = "select * from cms where pageKey='{$pageid}' and  itemName='{$itemName}' ";
        $rowval = $PDO_fun->getValue($query)->fetch();
        if (!is_null($rowval->globalName)) {
            $finalResult = $rowval->globalName;
        } else {
            $finalResult = "!+ {$pageid} {$itemName} {$htmlType} +!";
            if ($rowval->itemName != $itemName) {
                $queryin = "insert into cms(pageKey,itemName,htmlType) values('{$pageid}', '{$itemName}','{$htmlType}')";
                $PDO_fun->setValue($queryin);
            }
        }
    } catch (Exception $ex) {
        redirect("../404.php");
    }
    return <<<TEXT
            {$finalResult}
TEXT;
}

//function convertGlobalText($pageid, $itemName, $htmlType) {
//    global $dbconnection;
//    $finalResult = "!+ {$pageid} {$itemName} {$htmlType} +!";
//    //check wether available;
//    $query = "select * from cms where globalName='{$pageid}' and  itemName='{$itemName}' ";
//    $rowval = mysqli_fetch_array(mysqli_query($dbconnection, $query));
//    if (!is_null($rowval)) {
//        if (!is_null($rowval["description"])) {
//            $finalResult = $rowval["description"];
//        } else {
//            $finalResult = "!+ {$pageid} {$itemName} {$htmlType} +!";
//        }
//    } else {
//        $query = "insert into cms(globalName,itemName,htmlType) values('{$pageid}', '{$itemName}','{$htmlType}')";
//        mysqli_query($dbconnection, $query);
//    }
//    return <<<TEXT
//            {$finalResult}
//TEXT;
//}
?>
