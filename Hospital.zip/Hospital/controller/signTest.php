<?php

try {
    require './function.php';
    require '../model/DBconnector.php';
    require '../model/PDOConnector.php';
    require '../controller/sendmail.php';
    ?>

    <?php

    $utype = (String) $_POST["1"];
    $email = (String) $_POST["email"];
    $reemail = (String) $_POST["reemail"];
    $passwdord = (String) $_POST["pass"];
    $repasswdord = (String) $_POST["repass"];
    $date = (String) $_POST["bday"];
    $msg_stat = 1;
    if (!empty($email) & !empty($reemail) & !empty($passwdord) & !empty($repasswdord) & !empty($date) & !empty($utype)) {
        $allOK = (bool) true;
        if ($email === $reemail) {
            $emailOK = (bool) true;
        } else {
            redirect("../view/index.php");
        }
        if ($passwdord === $repasswdord) {
            $passOK = (bool) true;
        } else {
            redirect("../view/index.php");
        }
        if ($utype === "s") {
            $sm_user = (bool) true;
            $fname = (String) $_POST["fname"];
            $lname = (String) $_POST["lname"];
        } elseif ($utype === "b") {
            $bs_user = (bool) true;
            $bname = (String) $_POST["bname"];
        }
    }
    if (isset($allOK) & $allOK === true & $emailOK === true & $passOK === true) {
        $PDO_fun = new PDOConnector();
        $statid = 3;
        if (!empty($fname) & !empty($lname) & $sm_user === true) {
            $usTy_id = 3;
            $query = "insert into users(fname,lname,register_date_rgid,user_type_ust_id,bdy_esttab_bday_id,status_statid,msgStat_idmsgStat,user_hash ) values('$fname','$lname',";
        } elseif (!empty($bname) & $bs_user === true) {
            $usTy_id = 2;
            $query = "insert into users(bname,register_date_rgid,user_type_ust_id,bdy_esttab_bday_id, status_statid,msgStat_idmsgStat,user_hash ) values('$bname',";
        } else {
            redirect("../view/index.php");
        }
        //md5 hash
        $md5hash = str_split(md5($username) . md5($passwdord), 50);

        $regemail = $PDO_fun->getValue("select * from login");
        $regemailRow = $regemail->fetchAll();
        $regmailOK = false;
        foreach ($regemailRow as $value) {
            if ($value->username === $email) {
                redirect("../view/index.php");
            } else {
                $regmailOK = true;
            }
        }
        if ($regmailOK === true) {
            //register date
            $to_date = date("Y-m-d");
            $reg_qu = $PDO_fun->setValue("insert into register_date(rg_date) values(\"{$to_date}\")");
            $new_reg =(int) $PDO_fun->getValue("select max(rgid) from register_date")->fetchColumn();

            //bday
            $bdy_qu = $PDO_fun->setValue("insert into bdy_esttab(bday_est) values(\"{$date}\")");
            $new_bdy =(int) $PDO_fun->getValue("select max(bday_id) from bdy_esttab")->fetchColumn();

            $query.="{$new_reg},{$usTy_id},{$new_bdy},{$statid},{$msg_stat},'{$md5hash[0]}')";
            $userDet = $PDO_fun->setValue($query);
            $new_us =(int) $PDO_fun->getValue("select max(uid) from users")->fetchColumn();

            //$hashPass = pas;
            $logqu = "insert into login(username,password,Users_uid) values(\"{$email}\",\"{$passwdord}\",{$new_us})";
            $logDet = $PDO_fun->setValue($logqu);

            //send mail
            $mail_body = "http://localhost:90/webdiv/PhpFinal/view/activation.php?USACST={$md5hash[0]}";
            $mail->MsgHTML($mail_body);
            $mail->AddAddress($email, "saviru bandara");
            if (!$mail->Send()) {
//                echo "Mailer Error: " . $mail->ErrorInfo;
                  redirect("../view/index.php?uiStatus=sendmail");
            } else {
                  redirect("../view/index.php?uiStatus=error");
            }
        }
    } else {
        redirect("../view/index.php");
    }
} catch (Exception $exc) {
    redirect("../view/404.php");
}
?>