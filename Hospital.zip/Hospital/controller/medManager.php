<?php

try {
    require_once '../controller/function.php';
    require_once '../model/PDOConnector.php';
    session_start();
    if (isset($_SESSION["logmsg"]) && $_SESSION["logmsg"] != "wrong") {
        $usesess = $_SESSION["logmsg"];
        $referrer = $_SERVER["HTTP_REFERER"];
        if ($usesess->getusttype() === "1") {
            $filename = $_FILES["find"]["name"];
            $filesize = $_FILES["find"]["size"];
            $filetype = $_FILES["find"]["type"];
            $tmp_path = $_FILES["find"]["tmp_name"];
            if (isset($filename) & !empty($filename)) {
                $PDO_fun = new PDOConnector();
                $location = "../media/";
                if (move_uploaded_file($tmp_path, $location . $filename)) {
                    $rowid=$PDO_fun->getValue("select max(idmediaManager) from mediamanager");
                    $rowid_id = $rowid->fetchColumn();
                    $rowid_id++;
                    $id_status=$PDO_fun->setValue("insert into mediamanager(idmediaManager,mediaManagercol,solutions_status_idsolution) values({$rowid_id},\"media/{$filename}\",1)");
                    redirect($referrer);
                } else {
                    redirect($referrer);
                }
            } else {
                redirect($referrer);
            }
        } else {
            redirect($referrer);
        }
    } else {
        redirect($referrer);
    }
} catch (Exception $exc) {
    echo $exc->getTraceAsString();
}
