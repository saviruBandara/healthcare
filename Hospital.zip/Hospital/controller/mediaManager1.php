<?php

try {
    require_once '../controller/function.php';
    require_once '../model/PDOConnector.php';
    session_start();
    if (isset($_SESSION["logmsg"]) && $_SESSION["logmsg"] != "wrong") {    
    if (isset($_REQUEST["imghref"]) && !empty($_REQUEST["imghref"]) && isset($_REQUEST["objName"]) && !empty($_REQUEST["objName"])) {
        $imghref=(int)$_REQUEST["imghref"];
        $objName=(int)$_REQUEST["objName"];
        $query="insert into mediaobject_has_mediamanager(mediaManager_idmediaManager,mediaObject_idmediaObject)";
        $query.=" values($imghref,$objName)";
        $PDO_fun=new PDOConnector();
        $PDO_fun->setValue($query);
        redirect("../view/mediaManager.php");
    }else{
        echo 'values empty';
    }
    }else{
         echo 'no access';
    }
} catch (Exception $exc) {
    echo $exc->getTraceAsString();
}

