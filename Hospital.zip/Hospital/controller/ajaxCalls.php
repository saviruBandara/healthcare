<?php

require_once '../model/PDOConnector.php';
$PDO_fun = new PDOConnector();
$obj = "";
$obj1 = "";
$mediam = $PDO_fun->getValue("select * from mediamanager where solutions_status_idsolution=1");
while ($row = $mediam->fetchObject()) {
    $obj .= "<div class=\"fileItem\"> <a class=\"imagehref " . $row->idmediaManager . " \" id=\"../" . $row->mediaManagercol . "\">";
    $obj .= "<img width=\"150\" height=\"100px\" src=\"../" . $row->mediaManagercol . "\" title=\"../" . $row->mediaManagercol . "\"/></a>";
//    $obj .= "<a href=\"mediaManager.jsp?removeThumb=" .$row->idmediaManager. "#" + System.currentTimeMillis() + "\" class=\"delbutton\"></a>";
    $obj .= "</div>";
}
if (isset($_REQUEST["mediaID"]) && !empty($_REQUEST["mediaID"])) {
    $id = $_REQUEST["mediaID"];
    $int_id = (int) $id;
    if ($int_id === 0) {
        echo $obj;
    } else {
        $query = "select mediamanager.idmediaManager,mediamanager.mediaManagercol";
        $query .=" from mediamanager,mediaobject_has_mediamanager where";
        $query .=" mediamanager.idmediaManager=mediaobject_has_mediamanager.mediaManager_idmediaManager";
        $mediam = $PDO_fun->getValue($query);
        $inside = false;
        while ($row = $mediam->fetchObject()) {
            $inside = true;
            $obj1 .= "<div class=\"fileItem\"> <a class=\"imagehref " . $row->idmediaManager . " \" id=\"../" . $row->mediaManagercol . "\">";
            $obj1 .= "<img width=\"150\" height=\"100px\" src=\"../" . $row->mediaManagercol . "\" title=\"../" . $row->mediaManagercol . "\"/></a>";
//    $obj .= "<a href=\"mediaManager.jsp?removeThumb=" .$row->idmediaManager. "#" + System.currentTimeMillis() + "\" class=\"delbutton\"></a>";
            $obj1 .= "</div>";
        }
        if ($inside === false) {
            echo "No Items in this widget";
        }else{
            echo $obj1;
        }
    }
} else {
    echo $obj;
}