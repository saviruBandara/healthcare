<?php

require_once './function.php';
require_once '../model/PDOConnector.php';
require_once './classFile.php';
$refereURL = $_SERVER["HTTP_REFERER"];
try {
    session_start();
    if (isset($_SESSION["logmsg"]) && $_SESSION["logmsg"] != "wrong") {
        $usesess = $_SESSION["logmsg"];
        if (isset($_POST["country"]) && !empty($_POST["country"]) && isset($_POST["town"]) && !empty($_POST["town"]) &&
                isset($_POST["mobile"]) && !empty($_POST["mobile"]) && isset($_POST["mobile1"]) && !empty($_POST["mobile1"]) &&
                isset($_FILES["sinPro"]) && !empty($_FILES["sinPro"])) {
            $country = (String) $_POST["country"];
            $town = (String) $_POST["town"];
            $mobile = (int) $_POST["mobile"];
            $mobile1 = (int) $_POST["mobile1"];
            $filename = str_replace(" ", "_", $_FILES["sinPro"]["name"]);
            $tmp_path = $_FILES["sinPro"]["tmp_name"];
            $location = "../media/";
            if (move_uploaded_file($tmp_path, $location . $filename)) {
                $PDO_fun = new PDOConnector();
                $addId = (int) $PDO_fun->getValue("select max(idAddress) from address")->fetchColumn();
                $addId++;
                $query = "insert into address(country_couid,add2) values({$country},\"{$town}\")";
                $mobiID = "insert into mobileno(mobile1,mobile2,Users_uid) values({$mobile},{$mobile1},{$usesess->getUID()})";
                $updatequ = "update users set Address_idAddress={$addId},proimage=\"media/{$filename}\" where uid={$usesess->getUID()}";
                if ($PDO_fun->setValue($query) && $PDO_fun->setValue($updatequ) && $PDO_fun->setValue($mobiID)) {
                    redirect($refereURL);
                }
            }
        } else {
            redirect($refereURL);
        }
    } else {
        redirect($refereURL);
    }
} catch (Exception $exc) {
    echo $exc->getMessage();
}
