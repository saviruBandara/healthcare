<?php
require_once('./class.phpmailer.php');

$mail             = new PHPMailer();

$mail->IsSMTP(); // telling the class to use SMTP
$mail->Host       = "smtp.gmail.com"; // SMTP server
$mail->SMTPDebug  = 2;                     // enables SMTP debug information (for testing)
                                           // 1 = errors and messages
                                           // 2 = messages only
$mail->SMTPAuth   = true;                  // enable SMTP authentication
$mail->SMTPSecure = "tls";                 // sets the prefix to the servier
$mail->Host       = "smtp.gmail.com";      // sets GMAIL as the SMTP server
$mail->Port       = 587;                   // set the SMTP port for the GMAIL server
$mail->Username   = "saviru.tmail@gmail.com";  // GMAIL username
$mail->Password   = "savirumailtest";            // GMAIL password

$mail->SetFrom('saviru.tmail@gmail.com', 'Businesspage pvtltd');

$mail->AddReplyTo("saviru.tmail@gmail.com","Businesspage pvtltd");

$mail->Subject    = "Businesspage Activation codes.";

$mail->AltBody    = "To view the message, please use an HTML compatible email viewer!"; // optional, comment out and test
//$body="my name is php mailer gaas banda";
//$mail->MsgHTML($body);
//
//
////require_once('.php');
//$address = "saviru1993bandara@gmail.com";
//$mail->AddAddress($address, "saviru bandara");
//if(!$mail->Send()) {
//  echo "Mailer Error: " . $mail->ErrorInfo;
//} else {
//  echo "Message sent!";
//}
 ?>  
