<?php 
try {
    require './model/PDOConnector.php'; 
    require './controller/function.php';
    ?>

<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml">
    <head>
        <meta charset="UTF-8">
            <title><?=convertText('metaTag', "pageTitle", "htmlNone")?></title>
            <meta name="description" content="<?=convertText('metaTag', "metaDescription", "htmlNone")?>" />
            <meta name="dcterms.rightsHolder" content="<?=convertText("metaTag", "metaCopyright", "htmlNone")?>" />
            <meta name="dcterms.publisher" content="<?=convertText("metaTag", "metaPublisher", "htmlNone")?>" />
            <meta name="viewport" content="width=device-width, initial-scale=1.0, minimum-scale=1.0" />
            <meta name="google-site-verification" content="<?=convertText("metaTag", "metaGoogle-site-verification", "htmlNone")?>" />

            <!-- STYLES FOR SCREEN -->

            <link rel="stylesheet" href="css/global.defaults.css" />
            <link rel="stylesheet" href="css/global.fonts.css" />
            <link rel="stylesheet" href="css/global.layout.css" />
            <link rel="stylesheet" href="css/global.text.css" />
            <link rel="stylesheet" href="css/blue.css" />
            <link rel="stylesheet" href="css/style.css" />
            <link rel="stylesheet" href="css/animate.css" />
            <link rel="stylesheet" href="css/template.mediaquery.css" />
            <link rel="stylesheet" href="libs/jquery/jquery-ui.min.css" />

            <script type="text/javascript" src="libs/jquery/jquery-1.7.2.min.js"></script>
            <script type="text/javascript" src="libs/jquery/jquery-ui.min.js"></script>
            <script type="text/javascript" src="libs/jquery/jquery.easing.1.3.js"></script>
            <script type="text/javascript" src="libs/object.fancyboxIEPngLocationFix.js"></script>
            <script type="text/javascript" src="libs/scripts.js"></script>
            <script type="text/javascript" src="libs/ajax.js"></script>

            <?php
            if (isset($CSS_FILE)) {
                echo <<<EOD
       <link rel="stylesheet" href="css/template.{$CSS_FILE}.css"/>
EOD;
            }

            if (isset($useSlideShow) && $useSlideShow === true) {
                echo <<<EOD
        <link href="libs/jquery/rs-plugin/css/settings.css" rel="stylesheet">
        <script type="text/javascript" src="libs/jquery/rs-plugin/js/jquery.themepunch.tools.min.js"></script>
        <script type="text/javascript" src="libs/jquery/rs-plugin/js/jquery.themepunch.revolution.min.js"></script>
EOD;
            }

            if (isset($useFancybox) && $useFancybox === true) {
                echo <<<EOD
         <script type="text/javascript" src="libs/jquery/fancybox/jquery.fancybox-1.3.4.js"></script>
                <link rel="stylesheet" href="libs/jquery/fancybox/jquery.fancybox-1.3.4.css" />
EOD;
            }
//echo print_r(PDO::getAvailableDrivers());
           $PDO_fun = new PDOConnector();
} catch (Exception $exc) {
    redirect("404.php");
}
?>
