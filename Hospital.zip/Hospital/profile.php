<!DOCTYPE html>
<!--
To change this license header, choose License Headers in Project Properties.
To change this template file, choose Tools | Templates
and open the template in the editor.
-->
<?php
try {
    $pageKey = 'profile';
    $CSS_FILE = 'profile';
    $useFancybox = true;
    include './inc.bodyTop.php';
    if (isset($usesess) && $usesess->statusAvailable == 1) {
        ?>
        <script type="text/javascript">
            jQuery(document).ready(function() {
        <?php if (isset($_REQUEST["menucat"])) { ?>
                    var catmenu = "<?= $_REQUEST["menucat"] ?>";
                    jQuery('#submenu_bar ul.parentmenu li.ulid' + catmenu + " a").trigger('click');
        <?php } ?>
                jQuery('#submenu_bar ul.parentmenu li a').on('click' , function() {
                    var urlhash = window.location.href ;
                    var ulliid = jQuery(this).parents('li').attr('class').split(' ') ;
                    var splitid = ulliid[0].replace("ulid" , "") ;
                    if (urlhash.contains("&menucat=")) {
                        urlhash = urlhash.slice(0 , -1) ;
                        window.location.href = urlhash + splitid ;
                    } else {
                        urlhash = urlhash + "&menucat=" + splitid ;
                        window.location.href = urlhash ;
                    }
                }) ;
            }) ;
        </script>
        <div class="main posrel" id="main" role="main">
            <div class="main-intro section-inner">
                <div id="submenu_bar" class="section-inner">
                    <ul class="parentmenu">
                        <?php
                        $subitem = 7;
                        for ($i = 1; $i <= $subitem; $i++) {
                            if (($usesess->positionsId == 2)) {
                                continue;
//                        } else if ((user.getUserType().getUstId() == 2) && (i == 5 || i == 9 || i == 10 || i == 11)) {
//                        continue;
//                        } else if ((user.getUserType().getUstId() == 1) && i == 5) {
//                        continue;
                            } else {
                                ?>
                                <li class="ulid<?= $i ?> ">
                                    <a href="#tabs-<?= $i ?>"><?php echo convertText($pageKey, "tab" . $i . "title", "htmlStrip"); ?></a>
                                </li>
                                <?php
                            }
                        }
                        ?>
                    </ul>
                    <div id="tabs-1" class="home subtabs editMe">
                        <div class="subBar">
                            <ul>
                                <li class="ulid_sub1 ">
                                    <a href="#subtabs-1"><?php echo convertText($pageKey, "subtab" . 1 . "create-title", "htmlStrip"); ?></a>
                                </li> 
                                <li class="ulid_sub2 ">
                                    <a href="#subtabs-2"><?php echo convertText($pageKey, "subtab" . 2 . "update-title", "htmlStrip"); ?></a>
                                </li> 
                            </ul>
                        </div>
                        <div class="editMeTable">
                            <div id='subtabs-1'>
                            </div>
                            <div id='subtabs-2'>
                                <?php if (isset($_REQUEST["errbus"])) { ?>
                                    <div id="dialog-message" title="errror" style="color: red;margin-bottom: 10px ">
                                        <?php if ($_REQUEST["errbus"] === "fnlen") { ?>
                                            First Name Length too long
                                        <?php } elseif ($_REQUEST["errbus"] === "lnlen") { ?>
                                            Last Name Length too long
                                        <?php } elseif ($_REQUEST["errbus"] === "townlen") { ?>
                                            Town Name Length too long
                                        <?php } ?>
                                    </div>
                                <?php } ?>
                                <form name="buupdate" action="buupdate" enctype="multipart/form-data" method="post">
                                    <div class="tr labelTest"><label>First Name :</label>
                                        <input class="td labelremainse5 fname" disabled="true" type="text" required="true" name="fname" value="<?= $usesess->fname ?>">
                                        <input class="checkEdit" data-key="fname" type="checkbox" name="fnameCH" value="ON" >
                                    </div>
                                    <div class="tr labelTest"><label>Last Name :</label>
                                        <input class="td labelremainse5 lname" disabled="true" data-type="lname" type="text" required="true" name="lname" value="<?= $usesess->lname ?>">
                                        <input class="checkEdit" data-key="lname" type="checkbox" name="lanmeCH" value="ON" >         
                                    </div>
                                    <div class="tr labelTest"><label>Town</label>
                                        <input class="td labelremainse5 town" disabled="true" type="text" required="true" name="town" value="<? ?>">
                                        <input class="checkEdit" data-key="town" type="checkbox" name="townCH" value="ON" />
                                    </div>
                                    <div class="tr labelTest"><label>Birth Date :</label>
                                        <input class="td labelremainse5 datepicker date" disabled="true" type="date" required="true" name="date" value="<%=users.getDatetimeByBday().getDate()%>">
                                        <input class="checkEdit" data-key="date" type="checkbox" name="dateCH" value="ON" />
                                    </div>
                                    <div class="tr labelTest"><label>Contact Numbers :</label>
                                        <div class="twoField">
                                            <input class="td labelremainse5 mobile1" disabled="true" type="tel" required="true" name="phon1" value="<%=mobileno.getMobile1()%>">
                                            <input class="checkEdit" data-key="mobile1" type="checkbox" name="mobile1CH" value="ON" />
                                        </div>
                                    </div>
                                    <div class="tr labelTest"><label>Password :</label>
                                        <div class="twoField">
                                            <input class="td labelremainse5 passcur" disabled="true" type="password" required="true" name="pass" value="Enter New Password">
                                            <input class="checkEdit" data-key="passcur" type="checkbox" name="passnewCH" value="ON" />
                                            <input class="td labelremainse5 passcur oldpass" disabled="true" type="password" required="true" name="oldpass" value="Enter Current Password">
                                        </div>
                                    </div>
                                    <button class="proSave"><?php echo convertText($pageKey, "formeditme-enterButton", "htmlStrip"); ?></button>
                                </form>
                                
                            </div>
                        </div>   
                    </div>
                    <div id="tabs-2" class="home subtabs editMe"></div>
                    <div id="tabs-3" class="home subtabs editMe"></div>
                    <div id="tabs-4" class="home subtabs editMe"></div>
                    <div id="tabs-5" class="home subtabs editMe"></div>
                    <div id="tabs-6" class="home subtabs pageContent">
                        <div id="ad">
                            <table>
                                <thead>
                                <th> <select name="loca" class="locationSel" onchange="toollocation(this)">
                                        <?php
                                        $listcms = $PDO_fun->getValue("select distinct pageKey from Cms")->fetchAll();
                                        foreach ($listcms as $listcmsrow) {
                                            ?>
                                            <option data-cmstit="<?= $listcmsrow->pageKey ?>"><?= $listcmsrow->pageKey ?></option>
                                        <?php } ?>
                                    </select> </th>
                                <th>Parent Block</th>
                                <th>Html Type</th>
                                </thead>
                                <tbody>
                                    <?php
                                    $cmslist = $PDO_fun->getValue("select * from cms")->fetchAll();
                                    foreach ($cmslist as $cmslistrow) {
                                        ?>
                                        <tr class="rsCarousel <?= $cmslistrow->pageKey ?> <?= ($cmslistrow->pageKey == "metaTag") ? "" : "displaynone" ?>">
                                            <td><?= $cmslistrow->pageKey ?></td>
                                            <td class="dotted <?= ($cmslistrow->globalName == null) ? "nullValue" : "" ?> ">
                                                <a href="#popupForm-<?= $cmslistrow->idcms ?>"> <?= ($cmslistrow->globalName != null) ? $cmslistrow->globalName : $cmslistrow->itemName ?> </a>
                                                <div class="popupWrapper">
                                                    <form class="popup" id="popupForm-<?= $cmslistrow->idcms ?>" >
                                                        <div class="topbar">
                                                            <label>Location:<?= $cmslistrow->pageKey ?>|</label>
                                                            <label>Item:<?= $cmslistrow->itemName ?>|</label>
                                                            <label>Type:<?= $cmslistrow->htmlType ?></label>
                                                        </div>
                                                        <input type="text" class="itemText" placeholder="<?= ($cmslistrow->globalName != null) ? $cmslistrow->globalName : $cmslistrow->itemName ?>"/>
                                                        <input type="hidden" class="location" value="<?= $cmslistrow->pageKey ?>"/>
                                                        <input type="hidden" class="htmlType" value="<?= $cmslistrow->htmlType ?>"/>
                                                        <input type="hidden" class="itemName" value="<?= $cmslistrow->itemName ?>"/>
                                                        <button type="button" class="subPop">Enter</button>
                                                    </form>
                                                </div>
                                            </td>
                                            <td><?= $cmslistrow->htmlType ?></td>
                                        </tr>
                                        <?php
                                    }
                                    ?>
                                </tbody> 
                            </table>
                        </div>
                    </div>
                    <div id="tabs-7" class="home subtabs mediaManager">

                    </div>
                </div>
            </div>
        </div>
        <?php
    }
    include './inc.bodyBottom.php';
} catch (Exception $e) {
    redirect("../view/404.php");
}
?>

