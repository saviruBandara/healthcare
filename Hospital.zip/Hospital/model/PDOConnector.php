<?php

//require '../controller/function.php';
class PDOConnector {

    private $host = "localhost";
    private $dbname = "hospital";
    private $user = "root";
    private $pass = "123456";
    public $DBH;

    public function __construct() {
        try {
            $this->DBH = new PDO("mysql:host=$this->host;dbname=$this->dbname", $this->user, $this->pass, array(
                PDO::ATTR_PERSISTENT => true
            ));
            $this->DBH->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
            return $this->DBH;
        } catch (PDOException $e) {
            redirect("../Hospital/404.php");
        }
    }

    public function getValue($statement) {
        try {
            $STH = $this->DBH->query($statement);
            $STH->setFetchMode(PDO::FETCH_OBJ);
            return $STH;
        } catch (PDOException $e) {
            echo $e;
            redirect("../Hospital/404.php");
        }
    }

    public function setValue($statement) {
        try {
            $this->DBH->beginTransaction();
            $this->DBH->prepare($statement);
            $this->DBH->exec($statement);
            $this->DBH->commit();
            return "true";
        } catch (PDOException $e) {
            $this->DBH->rollBack();
            echo $e;
            echo var_dump($statement);
            redirect("../view/404.php?error{$e}");
        }
    }

}
