<!--
To change this license header, choose License Headers in Project Properties.
To change this template file, choose Tools | Templates
and open the template in the editor.
-->
<?php
try {
    $CSS_FILE = $pageKey = 'home';
    $useSlideShow = true;
    ?>

    <?php include 'inc.bodyTop.php' ?>

    <div class="main posrel" id="main" role="main">
        <div class="visualContent section-inner">
            <?php require_once './template.common.widget.slideshow2.php'; ?>
        </div>
        <div id="main-content" class="main-intro section-wrapper">
            <div id="container">
                <div class="resAdjust section-wrapper">
                    <div class="readMore">
                        <h1 class="main-title"><?php echo convertText($pageKey, 'metaH1', "htmlAllow"); ?></h1>
                        <h2 class="main-slogan"><?php echo convertText($pageKey, 'pageSubTitle', "htmlAllow"); ?></h2>
                        <div class="main-intro readmore">
                            <?php
                            $mainIntro = convertText($pageKey, 'mainIntro', "htmlAllow");
                            $start = strpos($mainIntro, '<p>');
                            $end = strpos($mainIntro, '</p>', $start);
                            $paragraph = substr($mainIntro, $start, $end - $start + 4);
                            $paragraph = html_entity_decode(strip_tags($paragraph));
                            $paragraph1 = substr($mainIntro, $end);
                            $paragraph1 = html_entity_decode(strip_tags($paragraph1));
                            ?>
                            <div class="container"><?= $paragraph ?></div>
                            <div class="hidden-container"><?= $paragraph1 ?></div>
                            <?php
                            if (!(empty($paragraph1)) & strlen($paragraph1) > 2) {
                                ?>
                                <a class="readmore-button" role="button">
                                    <span class="readmore"><?php echo convertText($pageKey, 'readmoreText', "htmlStrip"); ?></span>
                                    <span class="readless"><?php echo convertText($pageKey, 'readlessText', "htmlStrip"); ?></span>
                                </a>
                            <?php } ?>
                        </div>
                    </div>
                    <div class="contactUs">
                        <?php
                        $phone = str_replace(" ", "", convertText($pageKey, 'contactnohref', 'htmlNone'));
                        $phone1 = str_replace(" ", "", convertText($pageKey, 'reservContacthref', 'htmlNone'));
                        $phone2 = str_replace(" ", "", convertText($pageKey, 'reservContact1href', 'htmlNone'));
                        $phone3 = str_replace(" ", "", convertText($pageKey, 'headeQUContacthref', 'htmlNone'));
                        $email = str_replace(" ", "", convertText($pageKey, 'reservEmailhref', 'htmlNone'));
                        ?>
                        <h3 class="contactTitle"><?php echo convertText($pageKey, 'contactTitle', "htmlStrip"); ?></h3>
                        <div class="mainTel"><?php echo convertText($pageKey, 'PhoneLabel', "htmlStrip"); ?>
                            <a href="tel:<?= $phone ?>"><?php echo convertText($pageKey, 'contactno', "htmlStrip"); ?></a>
                        </div>
                        <div class="reservCenter"><?php echo convertText($pageKey, 'reservCenterText', "htmlStrip"); ?></h4>
                            <p class="reserv">
                                <span class="phone"><?php echo convertText($pageKey, 'PhoneLabel', "htmlStrip"); ?> 
                                    <a href="tel:<?= $phone1; ?>"><?php echo convertText($pageKey, 'reservContact', "htmlStrip"); ?>
                                    </a><br/>
                                    <a href="tel:<?= $phone2; ?>"><?php echo convertText($pageKey, 'reservContact1', "htmlStrip"); ?>
                                    </a>
                                </span>
                            </p>
                            <p class="open-details">
                                <?php echo convertText($pageKey, 'opening', "htmlStrip"); ?>
                            </p>
                            <p class="reserv-email">
                                <span class="email">
                                    <?php echo convertText($pageKey, 'emailLabel', "htmlStrip"); ?>
                                    <a href="mailto:<?= $email; ?>">
                                        <?php echo convertText($pageKey, 'reservEmail', "htmlStrip"); ?>
                                    </a>
                                </span>
                            </p>
                        </div>
                        <div class="headquaters">
                            <h4><?php echo convertText($pageKey, 'headquatersText', "htmlStrip"); ?></h4>
                            <p class="headQU-text">
                                <?php echo convertText($pageKey, 'opening1', "htmlStrip"); ?>
                            </p>
                            <p class="headQU-email">
                                <span class="email">
                                    <?php echo convertText($pageKey, 'PhoneLabel', "htmlStrip"); ?> 
                                    <a href="tel:<?= $phone3; ?>"><?php echo convertText($pageKey, 'headeQUContact', "htmlStrip"); ?>
                                    </a>
                                </span>
                            </p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="hideContent">
            <div id="login" class="section-inner">
                <form id="loging" action="controller/logtest.php" method="post" name="logingf">
                    <input class="inputStyle logininput" oninput="loginemailCheck()" required="required" type="email" name="email"  placeholder="enter your email" /><br/>
                    <input class="inputStyle logininput1" required="required" type="password" maxlength="14" name="pass"  placeholder="enter your password"/><br/>
                    <input id='remindME' type="checkbox" name="remind" value="YES" /><label>Keep me logged in</label>
                    <a id='forgme' target="new window" href="http://localhost:8080/FinaProject/forgotpass.jsp"/>
                    Forgot Your Password?</a><br/>
                    <button class="LoginbuttonStyle"  type="submit" name="lol">Login</button>  
                    <div id="formcheck1"></div> 
                </form> 
            </div>
        </div>
    </div> <!-- main -->
    <script type="text/javascript">
        jQuery(document).ready(function() {
            //Revolution Slider 4
            if ($(".slider-banner-container").length > 0) {

                $(".tp-bannertimer").show() ;
                $('body:not(.transparent-header) .slider-banner-container .slider-banner-fullscreen').show().revolution({
                    delay : 8000 ,
                    startwidth : 1140 ,
                    startheight : 520 ,
                    fullWidth : "off" ,
                    fullScreen : "on" ,
                    fullScreenOffsetContainer : ".header-container" ,
                    fullScreenOffset : "0" ,
                    navigationArrows : "solo" ,
                    navigationStyle : "preview2" ,
                    navigationHAlign : "center" ,
                    navigationVAlign : "bottom" ,
                    navigationHOffset : 0 ,
                    navigationVOffset : 20 ,
                    soloArrowLeftHalign : "left" ,
                    soloArrowLeftValign : "center" ,
                    soloArrowLeftHOffset : 0 ,
                    soloArrowLeftVOffset : 0 ,
                    soloArrowRightHalign : "right" ,
                    soloArrowRightValign : "center" ,
                    soloArrowRightHOffset : 0 ,
                    soloArrowRightVOffset : 0 ,
                    spinner : "spinner2" ,
                    stopLoop : "off" ,
                    stopAfterLoops : -1 ,
                    stopAtSlide : -1 ,
                    onHoverStop : "off" ,
                    shuffle : "off" ,
                    hideTimerBar : "off" ,
                    autoHeight : "off" ,
                    forceFullWidth : "off" ,
                    hideThumbsOnMobile : "off" ,
                    hideNavDelayOnMobile : 1500 ,
                    hideBulletsOnMobile : "off" ,
                    hideArrowsOnMobile : "off" ,
                    hideThumbsUnderResolution : 0 ,
                    hideSliderAtLimit : 0 ,
                    hideCaptionAtLimit : 0 ,
                    hideAllCaptionAtLilmit : 0 ,
                    startWithSlide : 0
                }) ;
                $('.transparent-header .slider-banner-container .slider-banner-fullscreen').show().revolution({
                    delay : 8000 ,
                    startwidth : 1140 ,
                    startheight : 520 ,
                    fullWidth : "off" ,
                    fullScreen : "on" ,
                    fullScreenOffsetContainer : ".header-top" ,
                    fullScreenOffset : "" ,
                    navigationArrows : "solo" ,
                    navigationStyle : "preview2" ,
                    navigationHAlign : "center" ,
                    navigationVAlign : "bottom" ,
                    navigationHOffset : 0 ,
                    navigationVOffset : 20 ,
                    soloArrowLeftHalign : "left" ,
                    soloArrowLeftValign : "center" ,
                    soloArrowLeftHOffset : 0 ,
                    soloArrowLeftVOffset : 0 ,
                    soloArrowRightHalign : "right" ,
                    soloArrowRightValign : "center" ,
                    soloArrowRightHOffset : 0 ,
                    soloArrowRightVOffset : 0 ,
                    spinner : "spinner2" ,
                    stopLoop : "off" ,
                    stopAfterLoops : -1 ,
                    stopAtSlide : -1 ,
                    onHoverStop : "off" ,
                    shuffle : "off" ,
                    hideTimerBar : "off" ,
                    autoHeight : "off" ,
                    forceFullWidth : "off" ,
                    hideThumbsOnMobile : "off" ,
                    hideNavDelayOnMobile : 1500 ,
                    hideBulletsOnMobile : "off" ,
                    hideArrowsOnMobile : "off" ,
                    hideThumbsUnderResolution : 0 ,
                    hideSliderAtLimit : 0 ,
                    hideCaptionAtLimit : 0 ,
                    hideAllCaptionAtLilmit : 0 ,
                    startWithSlide : 0
                }) ;
                $('.slider-banner-container .slider-banner-fullwidth').show().revolution({
                    delay : 8000 ,
                    startwidth : 1140 ,
                    startheight : 450 ,
                    navigationArrows : "solo" ,
                    navigationStyle : "preview2" ,
                    navigationHAlign : "center" ,
                    navigationVAlign : "bottom" ,
                    navigationHOffset : 0 ,
                    navigationVOffset : 20 ,
                    soloArrowLeftHalign : "left" ,
                    soloArrowLeftValign : "center" ,
                    soloArrowLeftHOffset : 0 ,
                    soloArrowLeftVOffset : 0 ,
                    soloArrowRightHalign : "right" ,
                    soloArrowRightValign : "center" ,
                    soloArrowRightHOffset : 0 ,
                    soloArrowRightVOffset : 0 ,
                    fullWidth : "on" ,
                    spinner : "spinner2" ,
                    stopLoop : "off" ,
                    stopAfterLoops : -1 ,
                    stopAtSlide : -1 ,
                    onHoverStop : "off" ,
                    shuffle : "off" ,
                    autoHeight : "off" ,
                    forceFullWidth : "off" ,
                    hideThumbsOnMobile : "off" ,
                    hideNavDelayOnMobile : 1500 ,
                    hideBulletsOnMobile : "off" ,
                    hideArrowsOnMobile : "off" ,
                    hideThumbsUnderResolution : 0 ,
                    hideSliderAtLimit : 0 ,
                    hideCaptionAtLimit : 0 ,
                    hideAllCaptionAtLilmit : 0 ,
                    startWithSlide : 0
                }) ;
                $('.slider-banner-container .slider-banner-fullwidth-big-height').show().revolution({
                    delay : 8000 ,
                    startwidth : 1140 ,
                    startheight : 650 ,
                    navigationArrows : "solo" ,
                    navigationStyle : "preview2" ,
                    navigationHAlign : "center" ,
                    navigationVAlign : "bottom" ,
                    navigationHOffset : 0 ,
                    navigationVOffset : 20 ,
                    soloArrowLeftHalign : "left" ,
                    soloArrowLeftValign : "center" ,
                    soloArrowLeftHOffset : 0 ,
                    soloArrowLeftVOffset : 0 ,
                    soloArrowRightHalign : "right" ,
                    soloArrowRightValign : "center" ,
                    soloArrowRightHOffset : 0 ,
                    soloArrowRightVOffset : 0 ,
                    fullWidth : "on" ,
                    spinner : "spinner2" ,
                    stopLoop : "off" ,
                    stopAfterLoops : -1 ,
                    stopAtSlide : -1 ,
                    onHoverStop : "off" ,
                    shuffle : "off" ,
                    autoHeight : "off" ,
                    forceFullWidth : "off" ,
                    hideThumbsOnMobile : "off" ,
                    hideNavDelayOnMobile : 1500 ,
                    hideBulletsOnMobile : "off" ,
                    hideArrowsOnMobile : "off" ,
                    hideThumbsUnderResolution : 0 ,
                    hideSliderAtLimit : 0 ,
                    hideCaptionAtLimit : 0 ,
                    hideAllCaptionAtLilmit : 0 ,
                    startWithSlide : 0
                }) ;
                $('.banner:not(.dark-bg) .slider-banner-container .slider-banner-boxedwidth').show().revolution({
                    delay : 8000 ,
                    startwidth : 1140 ,
                    startheight : 450 ,
                    navigationArrows : "solo" ,
                    navigationStyle : "preview2" ,
                    navigationHAlign : "center" ,
                    navigationVAlign : "bottom" ,
                    navigationHOffset : 0 ,
                    navigationVOffset : 20 ,
                    soloArrowLeftHalign : "left" ,
                    soloArrowLeftValign : "center" ,
                    soloArrowLeftHOffset : 0 ,
                    soloArrowLeftVOffset : 0 ,
                    soloArrowRightHalign : "right" ,
                    soloArrowRightValign : "center" ,
                    soloArrowRightHOffset : 0 ,
                    soloArrowRightVOffset : 0 ,
                    fullWidth : "off" ,
                    spinner : "spinner2" ,
                    shadow : 1 ,
                    stopLoop : "off" ,
                    stopAfterLoops : -1 ,
                    stopAtSlide : -1 ,
                    onHoverStop : "off" ,
                    shuffle : "off" ,
                    autoHeight : "off" ,
                    forceFullWidth : "off" ,
                    hideThumbsOnMobile : "off" ,
                    hideNavDelayOnMobile : 1500 ,
                    hideBulletsOnMobile : "off" ,
                    hideArrowsOnMobile : "off" ,
                    hideThumbsUnderResolution : 0 ,
                    hideSliderAtLimit : 0 ,
                    hideCaptionAtLimit : 0 ,
                    hideAllCaptionAtLilmit : 0 ,
                    startWithSlide : 0
                }) ;
                $('.banner.dark-bg .slider-banner-container .slider-banner-boxedwidth').show().revolution({
                    delay : 8000 ,
                    startwidth : 1140 ,
                    startheight : 450 ,
                    navigationArrows : "solo" ,
                    navigationStyle : "preview2" ,
                    navigationHAlign : "center" ,
                    navigationVAlign : "bottom" ,
                    navigationHOffset : 0 ,
                    navigationVOffset : 20 ,
                    soloArrowLeftHalign : "left" ,
                    soloArrowLeftValign : "center" ,
                    soloArrowLeftHOffset : 0 ,
                    soloArrowLeftVOffset : 0 ,
                    soloArrowRightHalign : "right" ,
                    soloArrowRightValign : "center" ,
                    soloArrowRightHOffset : 0 ,
                    soloArrowRightVOffset : 0 ,
                    fullWidth : "off" ,
                    spinner : "spinner2" ,
                    shadow : 3 ,
                    stopLoop : "off" ,
                    stopAfterLoops : -1 ,
                    stopAtSlide : -1 ,
                    onHoverStop : "off" ,
                    shuffle : "off" ,
                    autoHeight : "off" ,
                    forceFullWidth : "off" ,
                    hideThumbsOnMobile : "off" ,
                    hideNavDelayOnMobile : 1500 ,
                    hideBulletsOnMobile : "off" ,
                    hideArrowsOnMobile : "off" ,
                    hideThumbsUnderResolution : 0 ,
                    hideSliderAtLimit : 0 ,
                    hideCaptionAtLimit : 0 ,
                    hideAllCaptionAtLilmit : 0 ,
                    startWithSlide : 0
                }) ;
                $('.slider-banner-container .slider-banner-boxedwidth-no-shadow').show().revolution({
                    delay : 8000 ,
                    startwidth : 1140 ,
                    startheight : 450 ,
                    navigationArrows : "solo" ,
                    navigationStyle : "preview2" ,
                    navigationHAlign : "center" ,
                    navigationVAlign : "bottom" ,
                    navigationHOffset : 0 ,
                    navigationVOffset : 20 ,
                    soloArrowLeftHalign : "left" ,
                    soloArrowLeftValign : "center" ,
                    soloArrowLeftHOffset : 0 ,
                    soloArrowLeftVOffset : 0 ,
                    soloArrowRightHalign : "right" ,
                    soloArrowRightValign : "center" ,
                    soloArrowRightHOffset : 0 ,
                    soloArrowRightVOffset : 0 ,
                    fullWidth : "off" ,
                    spinner : "spinner2" ,
                    shadow : 0 ,
                    stopLoop : "off" ,
                    stopAfterLoops : -1 ,
                    stopAtSlide : -1 ,
                    onHoverStop : "off" ,
                    shuffle : "off" ,
                    autoHeight : "off" ,
                    forceFullWidth : "off" ,
                    hideThumbsOnMobile : "off" ,
                    hideNavDelayOnMobile : 1500 ,
                    hideBulletsOnMobile : "off" ,
                    hideArrowsOnMobile : "off" ,
                    hideThumbsUnderResolution : 0 ,
                    hideSliderAtLimit : 0 ,
                    hideCaptionAtLimit : 0 ,
                    hideAllCaptionAtLilmit : 0 ,
                    startWithSlide : 0
                }) ;
                $('.banner:not(.dark-bg) .slider-banner-container .slider-banner-boxedwidth-stopped').show().revolution({
                    delay : 8000 ,
                    startwidth : 1140 ,
                    startheight : 450 ,
                    navigationArrows : "solo" ,
                    navigationStyle : "preview2" ,
                    navigationHAlign : "center" ,
                    navigationVAlign : "bottom" ,
                    navigationHOffset : 0 ,
                    navigationVOffset : 20 ,
                    soloArrowLeftHalign : "left" ,
                    soloArrowLeftValign : "center" ,
                    soloArrowLeftHOffset : 0 ,
                    soloArrowLeftVOffset : 0 ,
                    soloArrowRightHalign : "right" ,
                    soloArrowRightValign : "center" ,
                    soloArrowRightHOffset : 0 ,
                    soloArrowRightVOffset : 0 ,
                    fullWidth : "off" ,
                    spinner : "spinner2" ,
                    shadow : 1 ,
                    stopLoop : "off" ,
                    stopAfterLoops : 0 ,
                    stopAtSlide : 1 ,
                    onHoverStop : "off" ,
                    shuffle : "off" ,
                    autoHeight : "off" ,
                    forceFullWidth : "off" ,
                    hideThumbsOnMobile : "off" ,
                    hideNavDelayOnMobile : 1500 ,
                    hideBulletsOnMobile : "off" ,
                    hideArrowsOnMobile : "off" ,
                    hideThumbsUnderResolution : 0 ,
                    hideSliderAtLimit : 0 ,
                    hideCaptionAtLimit : 0 ,
                    hideAllCaptionAtLilmit : 0 ,
                    startWithSlide : 0
                }) ;
                $('.banner.dark-bg .slider-banner-container .slider-banner-boxedwidth-stopped').show().revolution({
                    delay : 8000 ,
                    startwidth : 1140 ,
                    startheight : 450 ,
                    navigationArrows : "solo" ,
                    navigationStyle : "preview2" ,
                    navigationHAlign : "center" ,
                    navigationVAlign : "bottom" ,
                    navigationHOffset : 0 ,
                    navigationVOffset : 20 ,
                    soloArrowLeftHalign : "left" ,
                    soloArrowLeftValign : "center" ,
                    soloArrowLeftHOffset : 0 ,
                    soloArrowLeftVOffset : 0 ,
                    soloArrowRightHalign : "right" ,
                    soloArrowRightValign : "center" ,
                    soloArrowRightHOffset : 0 ,
                    soloArrowRightVOffset : 0 ,
                    fullWidth : "off" ,
                    spinner : "spinner2" ,
                    shadow : 3 ,
                    stopLoop : "off" ,
                    stopAfterLoops : 0 ,
                    stopAtSlide : 1 ,
                    onHoverStop : "off" ,
                    shuffle : "off" ,
                    autoHeight : "off" ,
                    forceFullWidth : "off" ,
                    hideThumbsOnMobile : "off" ,
                    hideNavDelayOnMobile : 1500 ,
                    hideBulletsOnMobile : "off" ,
                    hideArrowsOnMobile : "off" ,
                    hideThumbsUnderResolution : 0 ,
                    hideSliderAtLimit : 0 ,
                    hideCaptionAtLimit : 0 ,
                    hideAllCaptionAtLilmit : 0 ,
                    startWithSlide : 0
                }) ;
            }
            ;
        }) ;
    </script>
    <?php include 'inc.bodyBottom.php' ?>
    <?php
} catch (Exception $exc) {
    redirect("../view/404.php");
}
?>
