<script type="text/javascript">
	jQuery(document).ready(function(){
            alert("saviru");
		
	});
</script>
